module yagura

go 1.22
