// yagura (櫓) — a single-binary monitoring watchtower that speaks the
// Zabbix agent protocol. No external database, no runtime deps.
package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"yagura/internal/store"
	"yagura/internal/trigger"
	"yagura/internal/web"
	"yagura/internal/zbx"
)

func main() {
	var (
		dataDir = flag.String("data", "./data", "data directory")
		httpL   = flag.String("http", ":8086", "web UI / API listen address")
		trapL   = flag.String("trapper", ":10051", "zabbix trapper listen address (active checks / sender)")
		token   = flag.String("token", "", "API bearer token (empty = no auth)")
		pollers = flag.Int("pollers", 8, "passive check worker count")
	)
	flag.Parse()
	if v := os.Getenv("YAGURA_TOKEN"); v != "" && *token == "" {
		*token = v
	}

	st, err := store.Open(*dataDir)
	if err != nil {
		log.Fatalf("store: %v", err)
	}

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	eng := &trigger.Engine{St: st, Interval: 15 * time.Second}
	go eng.Run(ctx)

	pol := &zbx.Poller{St: st, Workers: *pollers}
	go pol.Run(ctx)

	trap := &zbx.Trapper{St: st, Addr: *trapL}
	go func() {
		if err := trap.Run(ctx); err != nil {
			log.Fatalf("trapper: %v", err)
		}
	}()

	// nightly retention sweep
	go func() {
		t := time.NewTicker(24 * time.Hour)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				days := st.Settings().RetentionDays
				log.Printf("retention sweep: dropping data older than %d days", days)
				st.TS.Retention(days)
			}
		}
	}()

	srv := &web.Server{St: st, Eng: eng, Token: *token, Listen: *httpL}
	log.Printf("yagura 櫓 — web UI on %s, trapper on %s, data in %s", *httpL, *trapL, *dataDir)
	go func() {
		if err := srv.Run(); err != nil {
			log.Fatalf("http: %v", err)
		}
	}()

	<-ctx.Done()
	log.Println("shutting down")
}
