// Package tpl imports Zabbix configuration exports (JSON format,
// Zabbix 5.4+ / 6.x / 7.x schema). YAML exports can be converted with:
//
//	yq -o=json template.yaml > template.json
package tpl

import (
	"encoding/json"
	"fmt"
	"strings"

	"yagura/internal/store"
	"yagura/internal/trigger"
)

type export struct {
	ZabbixExport struct {
		Version   string    `json:"version"`
		Templates []zbxTpl  `json:"templates"`
		Triggers  []zbxTrig `json:"triggers"` // multi-item triggers (root level)
	} `json:"zabbix_export"`
}

type zbxTpl struct {
	Template       string    `json:"template"`
	Name           string    `json:"name"`
	Items          []zbxItem `json:"items"`
	DiscoveryRules []any     `json:"discovery_rules"`
}

type zbxItem struct {
	Name      string    `json:"name"`
	Key       string    `json:"key"`
	Type      string    `json:"type"`       // absent = ZABBIX_PASSIVE
	ValueType string    `json:"value_type"` // absent = FLOAT
	Delay     string    `json:"delay"`      // absent = 1m
	Units     string    `json:"units"`
	Status    string    `json:"status"` // DISABLED
	SNMPOID   string    `json:"snmp_oid"`
	Preproc   []zbxPre  `json:"preprocessing"`
	Triggers  []zbxTrig `json:"triggers"`
}

type zbxPre struct {
	Type       string   `json:"type"`
	Parameters []string `json:"parameters"`
}

type zbxTrig struct {
	Name       string `json:"name"`
	Expression string `json:"expression"`
	Priority   string `json:"priority"`
}

var sevMap = map[string]int{
	"NOT_CLASSIFIED": 0, "INFO": 1, "INFORMATION": 1, "WARNING": 2,
	"AVERAGE": 3, "HIGH": 4, "DISASTER": 5,
}

// Result summarizes what an import produced.
type Result struct {
	Templates []string `json:"templates"`
	Items     int      `json:"items"`
	Triggers  int      `json:"triggers"`
	Skipped   []string `json:"skipped"`
}

// Import parses a Zabbix JSON export and stores the templates.
func Import(st *store.Store, raw []byte) (*Result, error) {
	var ex export
	if err := json.Unmarshal(raw, &ex); err != nil {
		return nil, fmt.Errorf("not a Zabbix JSON export: %w", err)
	}
	if len(ex.ZabbixExport.Templates) == 0 {
		return nil, fmt.Errorf("no templates found (YAML exports: convert with `yq -o=json`)")
	}
	res := &Result{}
	for _, zt := range ex.ZabbixExport.Templates {
		name := zt.Template
		if name == "" {
			name = zt.Name
		}
		t := &store.Template{Name: name}
		for _, zi := range zt.Items {
			ti := store.TplItem{
				Name: zi.Name, Key: zi.Key, Units: zi.Units, Enabled: true,
			}
			switch zi.Type {
			case "", "ZABBIX_PASSIVE":
				ti.Type = store.Passive
			case "ZABBIX_ACTIVE":
				ti.Type = store.Active
			case "TRAP":
				ti.Type = store.Trapper
			case "SNMP_AGENT":
				oid := strings.TrimSpace(zi.SNMPOID)
				if strings.HasPrefix(oid, "walk[") {
					ti.Type = store.Trapper
					ti.Enabled = false
					ti.Note = "snmp walk[] not supported (needs LLD); feed via zabbix_sender or skip"
					res.Skipped = append(res.Skipped,
						fmt.Sprintf("%s / %s (snmp walk → disabled)", name, zi.Key))
				} else {
					ti.Type = store.SNMP
					ti.SNMPOID = oid
				}
			default:
				// unsupported collectors (SNMP, CALC, DEPENDENT, HTTP, ...)
				ti.Type = store.Trapper
				ti.Enabled = false
				ti.Note = "unsupported source type " + zi.Type + " (imported disabled; feed via zabbix_sender or skip)"
				res.Skipped = append(res.Skipped,
					fmt.Sprintf("%s / %s (type %s → disabled)", name, zi.Key, zi.Type))
			}
			switch zi.ValueType {
			case "", "FLOAT", "UNSIGNED":
				ti.ValueType = store.VFloat
			default: // CHAR, TEXT, LOG
				ti.ValueType = store.VText
			}
			if sec, err := parseDelay(zi.Delay); err == nil && sec > 0 {
				ti.DelaySec = sec
			} else {
				ti.DelaySec = 60
			}
			for _, pp := range zi.Preproc {
				switch pp.Type {
				case "MULTIPLIER", "CHANGE_PER_SECOND":
					prm := ""
					if len(pp.Parameters) > 0 {
						prm = pp.Parameters[0]
					}
					ti.Preproc = append(ti.Preproc, store.PreStep{Type: pp.Type, Params: prm})
				case "DISCARD_UNCHANGED", "DISCARD_UNCHANGED_HEARTBEAT":
					// safe to ignore: pure traffic optimization
				default:
					if ti.Enabled {
						ti.Enabled = false
						ti.Note = "unsupported preprocessing " + pp.Type + " (imported disabled)"
						res.Skipped = append(res.Skipped,
							fmt.Sprintf("%s / %s (preprocessing %s → disabled)", name, zi.Key, pp.Type))
					}
				}
			}
			if zi.Status == "DISABLED" {
				ti.Enabled = false
			}
			t.Items = append(t.Items, ti)
			res.Items++
			for _, ztr := range zi.Triggers {
				if tt, ok := convTrigger(name, ztr); ok {
					t.Triggers = append(t.Triggers, tt)
					res.Triggers++
				} else {
					res.Skipped = append(res.Skipped,
						fmt.Sprintf("trigger %q (unsupported expression)", ztr.Name))
				}
			}
		}
		if n := len(zt.DiscoveryRules); n > 0 {
			res.Skipped = append(res.Skipped,
				fmt.Sprintf("%s: %d discovery rules (LLD not supported yet)", name, n))
		}
		// root-level triggers that reference only this template
		for _, ztr := range ex.ZabbixExport.Triggers {
			if strings.Contains(ztr.Expression, "/"+name+"/") {
				if tt, ok := convTrigger(name, ztr); ok {
					t.Triggers = append(t.Triggers, tt)
					res.Triggers++
				}
			}
		}
		t.Skipped = len(res.Skipped)
		st.PutTemplate(t)
		res.Templates = append(res.Templates, name)
	}
	return res, nil
}

// convTrigger validates that our engine can parse the expression.
func convTrigger(tplName string, zt zbxTrig) (store.TplTrigger, bool) {
	expr := zt.Expression
	// validate using a placeholder host (expression keeps the template
	// name; it is rewritten to the real host on link)
	test := strings.ReplaceAll(expr, "/"+tplName+"/", "/_h_/")
	if _, err := trigger.Parse(test); err != nil {
		return store.TplTrigger{}, false
	}
	sev := sevMap[strings.ToUpper(zt.Priority)]
	return store.TplTrigger{Name: zt.Name, Expression: expr, Severity: sev}, true
}

func parseDelay(d string) (int, error) {
	if d == "" {
		return 60, nil
	}
	// flexible intervals: take the part before ';'
	if i := strings.IndexByte(d, ';'); i >= 0 {
		d = d[:i]
	}
	if strings.HasPrefix(d, "{") { // user macro — fall back to 60s
		return 60, nil
	}
	sec, err := trigger.ParseDuration(d)
	return int(sec), err
}
