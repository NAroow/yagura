// Package zbx implements the Zabbix wire protocol (header framing),
// passive-check polling and the trapper listener (active checks +
// zabbix_sender), compatible with zabbix-agent / zabbix-agent2.
package zbx

import (
	"bytes"
	"compress/zlib"
	"encoding/binary"
	"fmt"
	"io"
)

var header = []byte{'Z', 'B', 'X', 'D', 0x01}

const maxPacket = 64 << 20 // 64 MiB safety cap

// WritePacket frames data with the ZBXD\x01 header.
func WritePacket(w io.Writer, data []byte) error {
	buf := make([]byte, 13+len(data))
	copy(buf, header)
	binary.LittleEndian.PutUint32(buf[5:9], uint32(len(data)))
	// bytes 9..13: reserved (high 32 bits of length, always 0 here)
	copy(buf[13:], data)
	_, err := w.Write(buf)
	return err
}

// ReadPacket reads one ZBXD-framed message.
func ReadPacket(r io.Reader) ([]byte, error) {
	hd := make([]byte, 13)
	if _, err := io.ReadFull(r, hd); err != nil {
		return nil, err
	}
	if string(hd[:4]) != "ZBXD" {
		return nil, fmt.Errorf("bad protocol header %q", hd[:4])
	}
	compressed := hd[4]&0x02 != 0
	n := binary.LittleEndian.Uint32(hd[5:9])
	if n > maxPacket {
		return nil, fmt.Errorf("packet too large: %d", n)
	}
	data := make([]byte, n)
	if _, err := io.ReadFull(r, data); err != nil {
		return nil, err
	}
	if compressed {
		// Modern zabbix-agent / agent2 zlib-compress their payloads
		// (notably active-check data submissions); the ZBXD flag 0x02 marks
		// it and header bytes 9..13 hold the original uncompressed length.
		zr, err := zlib.NewReader(bytes.NewReader(data))
		if err != nil {
			return nil, fmt.Errorf("zlib open: %w", err)
		}
		defer zr.Close()
		out, err := io.ReadAll(io.LimitReader(zr, maxPacket))
		if err != nil {
			return nil, fmt.Errorf("zlib inflate: %w", err)
		}
		return out, nil
	}
	return data, nil
}
