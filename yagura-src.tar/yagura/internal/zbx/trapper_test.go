package zbx

import (
	"encoding/json"
	"testing"

	"yagura/internal/store"
)

// Zabbix 7.0 active agents reference items by the itemid handed out in the
// active-check list (not by key, the way 6.x agents and zabbix_sender do).
// resolveItem must handle both, or 7.0 active data is dropped.
func TestResolveItem(t *testing.T) {
	st, err := store.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	h := st.AddHost(&store.Host{Name: "h1", Enabled: true})
	it := st.AddItem(&store.Item{HostID: h.ID, Key: "agent.ping",
		Type: store.Active, ValueType: store.VFloat, Enabled: true})
	tr := &Trapper{St: st}

	// 7.0 style: itemid only, no host/key on the data point.
	got, ok := tr.resolveItem(request{Host: "h1"},
		dataPoint{ItemID: it.ID, Value: json.RawMessage(`"1"`)})
	if !ok || got.ID != it.ID {
		t.Fatalf("itemid resolution failed: ok=%v", ok)
	}

	// 6.x / zabbix_sender style: host + key.
	got, ok = tr.resolveItem(request{Host: "h1"}, dataPoint{Key: "agent.ping"})
	if !ok || got.ID != it.ID {
		t.Fatalf("host+key resolution failed: ok=%v", ok)
	}

	// Unknown itemid is rejected.
	if _, ok = tr.resolveItem(request{}, dataPoint{ItemID: 99999}); ok {
		t.Fatal("unknown itemid resolved")
	}
}

// Data pushed for an item whose host is disabled must be rejected even when
// addressed by itemid.
func TestResolveItemDisabledHost(t *testing.T) {
	st, err := store.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	h := st.AddHost(&store.Host{Name: "h1", Enabled: false})
	it := st.AddItem(&store.Item{HostID: h.ID, Key: "agent.ping",
		Type: store.Active, ValueType: store.VFloat, Enabled: true})
	tr := &Trapper{St: st}
	if _, ok := tr.resolveItem(request{}, dataPoint{ItemID: it.ID}); ok {
		t.Fatal("itemid on a disabled host was accepted")
	}
}
