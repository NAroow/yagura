package zbx

import (
	"bytes"
	"compress/zlib"
	"encoding/binary"
	"testing"
)

// compressedPacket frames a payload the way a modern zabbix-agent/agent2 does
// when it submits active-check data: ZBXD | flags=0x03 (proto|compress) |
// compressed_len(4) | uncompressed_len(4) | zlib(payload).
func compressedPacket(payload []byte) []byte {
	var zb bytes.Buffer
	zw := zlib.NewWriter(&zb)
	zw.Write(payload)
	zw.Close()
	comp := zb.Bytes()
	buf := make([]byte, 13+len(comp))
	copy(buf, []byte{'Z', 'B', 'X', 'D', 0x03})
	binary.LittleEndian.PutUint32(buf[5:9], uint32(len(comp)))
	binary.LittleEndian.PutUint32(buf[9:13], uint32(len(payload)))
	copy(buf[13:], comp)
	return buf
}

// Regression guard for the bug where active checks silently failed: modern
// agents compress their data, and ReadPacket used to reject the 0x02 flag.
func TestReadCompressedPacket(t *testing.T) {
	payload := []byte(`{"request":"agent data","data":[{"host":"web01","key":"agent.ping","value":"1"}]}`)
	got, err := ReadPacket(bytes.NewReader(compressedPacket(payload)))
	if err != nil {
		t.Fatalf("ReadPacket rejected a compressed packet: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("decompressed payload mismatch:\n got %s\nwant %s", got, payload)
	}
}

// Plain (uncompressed) packets must still round-trip.
func TestReadWriteUncompressed(t *testing.T) {
	payload := []byte(`{"response":"success"}`)
	var buf bytes.Buffer
	if err := WritePacket(&buf, payload); err != nil {
		t.Fatal(err)
	}
	got, err := ReadPacket(&buf)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("got %s want %s", got, payload)
	}
}
