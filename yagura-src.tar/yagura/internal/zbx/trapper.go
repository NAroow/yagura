package zbx

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"time"

	"yagura/internal/store"
)

// Trapper serves the zabbix server side of port 10051:
//   - "active checks"          → item list for active agents
//   - "agent data"             → values pushed by active agents
//   - "sender data"            → values pushed by zabbix_sender
//   - "active check heartbeat" → ack (agent2 keepalive)
type Trapper struct {
	St   *store.Store
	Addr string
}

type request struct {
	Request string      `json:"request"`
	Host    string      `json:"host"`
	Data    []dataPoint `json:"data"`
}

type dataPoint struct {
	Host  string          `json:"host"`
	Key   string          `json:"key"`
	Value json.RawMessage `json:"value"`
	Clock int64           `json:"clock"`
}

type activeItem struct {
	Key         string `json:"key"`
	Delay       string `json:"delay"`
	LastLogSize int64  `json:"lastlogsize"`
	Mtime       int64  `json:"mtime"`
}

func (t *Trapper) Run(ctx context.Context) error {
	ln, err := net.Listen("tcp", t.Addr)
	if err != nil {
		return err
	}
	go func() { <-ctx.Done(); ln.Close() }()
	log.Printf("trapper listening on %s (active checks / zabbix_sender)", t.Addr)
	for {
		conn, err := ln.Accept()
		if err != nil {
			select {
			case <-ctx.Done():
				return nil
			default:
				continue
			}
		}
		go t.handle(conn)
	}
}

func (t *Trapper) handle(conn net.Conn) {
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(30 * time.Second))
	data, err := ReadPacket(conn)
	if err != nil {
		return
	}
	var req request
	if err := json.Unmarshal(data, &req); err != nil {
		return
	}
	switch req.Request {
	case "active checks":
		t.activeChecks(conn, req.Host)
	case "agent data", "sender data":
		t.ingest(conn, req)
	case "active check heartbeat":
		writeJSON(conn, map[string]string{"response": "success"})
	default:
		writeJSON(conn, map[string]string{"response": "failed",
			"info": "unsupported request: " + req.Request})
	}
}

func (t *Trapper) activeChecks(conn net.Conn, hostName string) {
	h, ok := t.St.HostByName(hostName)
	if !ok || !h.Enabled {
		writeJSON(conn, map[string]string{"response": "failed",
			"info": fmt.Sprintf("host %q not found", hostName)})
		return
	}
	items := []activeItem{}
	for _, it := range t.St.Items(h.ID) {
		if it.Type != store.Active || !it.Enabled {
			continue
		}
		d := it.DelaySec
		if d <= 0 {
			d = 60
		}
		items = append(items, activeItem{Key: it.Key, Delay: fmt.Sprintf("%ds", d)})
	}
	writeJSON(conn, map[string]any{"response": "success", "data": items})
}

func (t *Trapper) ingest(conn net.Conn, req request) {
	start := time.Now()
	processed, failed := 0, 0
	for _, dp := range req.Data {
		hostName := dp.Host
		if hostName == "" {
			hostName = req.Host
		}
		h, ok := t.St.HostByName(hostName)
		if !ok || !h.Enabled {
			failed++
			continue
		}
		it, ok := t.St.ItemByKey(h.ID, dp.Key)
		if !ok || !it.Enabled || (it.Type != store.Trapper && it.Type != store.Active) {
			failed++
			continue
		}
		// value may be a JSON string or a bare number
		var raw string
		if err := json.Unmarshal(dp.Value, &raw); err != nil {
			raw = string(dp.Value)
		}
		if t.St.Ingest(it, dp.Clock, raw) != nil {
			failed++
			continue
		}
		processed++
	}
	info := fmt.Sprintf("processed: %d; failed: %d; total: %d; seconds spent: %f",
		processed, failed, processed+failed, time.Since(start).Seconds())
	writeJSON(conn, map[string]string{"response": "success", "info": info})
}

func writeJSON(conn net.Conn, v any) {
	b, _ := json.Marshal(v)
	WritePacket(conn, b)
}
