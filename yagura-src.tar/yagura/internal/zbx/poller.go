package zbx

import (
	"context"
	"log"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"

	"yagura/internal/snmp"
	"yagura/internal/store"
)

// Poller drives passive checks: it dials each host's zabbix agent
// (default port 10050), sends the item key and ingests the response.
type Poller struct {
	St      *store.Store
	Workers int
	Timeout time.Duration

	mu   sync.Mutex
	next map[int64]int64 // item id -> next poll unix
}

func (p *Poller) Run(ctx context.Context) {
	if p.Workers <= 0 {
		p.Workers = 8
	}
	if p.Timeout == 0 {
		p.Timeout = 5 * time.Second
	}
	p.next = map[int64]int64{}
	q := make(chan *store.Item, 256)
	for i := 0; i < p.Workers; i++ {
		go func() {
			for it := range q {
				p.poll(it)
			}
		}()
	}
	tick := time.NewTicker(time.Second)
	defer tick.Stop()
	for {
		select {
		case <-ctx.Done():
			close(q)
			return
		case <-tick.C:
			now := time.Now().Unix()
			for _, it := range p.St.Items(0) {
				if (it.Type != store.Passive && it.Type != store.SNMP) || !it.Enabled {
					continue
				}
				h, ok := p.St.Host(it.HostID)
				if !ok || !h.Enabled || h.Addr == "" {
					continue
				}
				p.mu.Lock()
				nx, seen := p.next[it.ID]
				if !seen {
					// stagger first polls to avoid a thundering herd
					nx = now + int64(it.ID%10)
					p.next[it.ID] = nx
				}
				due := now >= nx
				if due {
					d := it.DelaySec
					if d <= 0 {
						d = 60
					}
					p.next[it.ID] = now + int64(d)
				}
				p.mu.Unlock()
				if due {
					select {
					case q <- it:
					default: // queue full; skip this round
					}
				}
			}
		}
	}
}

func (p *Poller) poll(it *store.Item) {
	h, ok := p.St.Host(it.HostID)
	if !ok {
		return
	}
	if it.Type == store.SNMP {
		p.pollSNMP(h, it)
		return
	}
	addr := h.Addr
	if !strings.Contains(addr, ":") {
		addr += ":10050"
	}
	conn, err := net.DialTimeout("tcp", addr, p.Timeout)
	if err != nil {
		p.St.SetItemError(it.ID, "connect: "+err.Error())
		return
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(p.Timeout))
	if err := WritePacket(conn, []byte(it.Key)); err != nil {
		p.St.SetItemError(it.ID, "send: "+err.Error())
		return
	}
	data, err := ReadPacket(conn)
	if err != nil {
		p.St.SetItemError(it.ID, "recv: "+err.Error())
		return
	}
	val := string(data)
	if strings.HasPrefix(val, "ZBX_NOTSUPPORTED") {
		reason := "unsupported by agent"
		if i := strings.IndexByte(val, 0); i >= 0 && i+1 < len(val) {
			reason = val[i+1:]
		}
		p.St.SetItemError(it.ID, "ZBX_NOTSUPPORTED: "+reason)
		return
	}
	if err := p.St.Ingest(it, 0, val); err != nil {
		log.Printf("ingest %s[%s]: %v", h.Name, it.Key, err)
	}
}

// pollSNMP fetches one SNMP item via v1/v2c GET.
func (p *Poller) pollSNMP(h *store.Host, it *store.Item) {
	if it.SNMPOID == "" {
		p.St.SetItemError(it.ID, "no snmp_oid configured")
		return
	}
	host := h.Addr
	if i := strings.LastIndexByte(host, ':'); i > 0 && !strings.Contains(host, "]") {
		host = host[:i] // strip agent port; SNMP has its own
	}
	port := h.SNMPPort
	if port <= 0 {
		port = 161
	}
	c := &snmp.Client{
		Addr:      net.JoinHostPort(host, strconv.Itoa(port)),
		Community: h.SNMPCommunity,
		Version:   h.SNMPVersion,
		Timeout:   p.Timeout,
	}
	v, err := c.Get(it.SNMPOID)
	if err != nil {
		p.St.SetItemError(it.ID, "snmp: "+err.Error())
		return
	}
	raw := v.S
	if !v.IsStr {
		raw = strconv.FormatFloat(v.F, 'f', -1, 64)
	}
	if err := p.St.Ingest(it, 0, raw); err != nil {
		log.Printf("ingest snmp %s[%s]: %v", h.Name, it.Key, err)
	}
}
