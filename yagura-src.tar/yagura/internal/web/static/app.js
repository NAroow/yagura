/* yagura 櫓 — SPA (no dependencies) */
"use strict";

const $ = (sel, el = document) => el.querySelector(sel);
const main = $("#main");
const SEV = ["Not classified", "Information", "Warning", "Average", "High", "Disaster"];

// ---- i18n ----
let T = {};
function lang() {
  return localStorage.getItem("yagura_lang") ||
    ((navigator.language || "").toLowerCase().startsWith("ja") ? "ja" : "en");
}
function loc() { return lang() === "ja" ? "ja-JP" : "en-GB"; }
function t(k, ...a) {
  let s = (T && T[k] != null) ? T[k] : k;
  a.forEach((v, i) => { s = s.split("{" + i + "}").join(v); });
  return s;
}
function sevName(i) { return (T.sev && T.sev[i]) || SEV[i] || "?"; }

let token = localStorage.getItem("yagura_token") || "";

// ---- api ----
async function api(path, opts = {}) {
  opts.headers = Object.assign({}, opts.headers);
  if (token) opts.headers["Authorization"] = "Bearer " + token;
  if (opts.body && typeof opts.body !== "string") opts.body = JSON.stringify(opts.body);
  const r = await fetch(path, opts);
  if (r.status === 401) {
    const tok = prompt(t("prompt_token"));
    if (tok) { token = tok; localStorage.setItem("yagura_token", tok); return api(path, opts); }
    throw new Error("unauthorized");
  }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || r.statusText);
  return j;
}

// ---- helpers ----
function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") e.className = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (k === "html") e.innerHTML = v;
    else e.setAttribute(k, v);
  }
  for (const k of kids.flat()) {
    if (k == null) continue;
    e.append(k.nodeType ? k : document.createTextNode(k));
  }
  return e;
}
function toast(msg, bad = false) {
  const t = el("div", { class: "toast" + (bad ? " bad" : "") }, msg);
  document.body.append(t);
  setTimeout(() => t.remove(), 3500);
}
function fmtTime(unix) {
  if (!unix) return "—";
  const d = new Date(unix * 1000);
  return d.toLocaleString(loc(), { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
function ago(unix) {
  if (!unix) return "—";
  const s = Math.floor(Date.now() / 1000) - unix;
  if (s < 60) return t("ago_s", s);
  if (s < 3600) return t("ago_m", Math.floor(s / 60));
  if (s < 86400) return t("ago_h", Math.floor(s / 3600));
  return t("ago_d", Math.floor(s / 86400));
}
function fmtVal(v, units) {
  const n = parseFloat(v);
  if (isNaN(n) || v === "" || /[^0-9eE+\-. ]/.test(v)) return v;
  let out;
  if (units === "bps") {
    const x = Math.abs(n), sign = n < 0 ? "-" : "";
    if (x >= 1e9)      out = sign + (x / 1e9).toFixed(2) + " Gbps";
    else               out = sign + (x / 1e6).toFixed(x >= 1e6 ? 1 : x >= 1e4 ? 2 : 3) + " Mbps";
  } else if (units === "B" || units === "Bps") {
    const u = ["", "K", "M", "G", "T", "P"];
    let x = Math.abs(n), i = 0;
    while (x >= 1024 && i < u.length - 1) { x /= 1024; i++; }
    out = (n < 0 ? "-" : "") + x.toFixed(x >= 100 || i === 0 ? 0 : 2) + " " + u[i] + (units === "Bps" ? "B/s" : "B");
  } else if (units === "s" && n >= 60) {
    const d = Math.floor(n / 86400), h = Math.floor(n % 86400 / 3600), m = Math.floor(n % 3600 / 60);
    out = (d ? d + "d " : "") + (h ? h + "h " : "") + m + "m";
  } else if (units === "uptime" && n >= 60) {
    out = fmtVal(String(n), "s");
  } else {
    out = Math.abs(n) >= 1e6 || (Math.abs(n) < 0.001 && n !== 0) ? n.toExponential(2)
      : String(Math.round(n * 10000) / 10000);
    if (units) out += " " + units;
  }
  return out;
}

// ---- canvas charts ----
function drawSpark(cv, pts) {
  const dpr = devicePixelRatio || 1;
  const W = 110, H = 26;
  cv.width = W * dpr; cv.height = H * dpr;
  const g = cv.getContext("2d");
  g.scale(dpr, dpr);
  if (!pts || pts.length < 2) return;
  const vs = pts.map(p => p.v);
  let lo = Math.min(...vs), hi = Math.max(...vs);
  if (hi === lo) { hi += 1; lo -= 1; }
  g.strokeStyle = "#E8A33D"; g.lineWidth = 1.4; g.beginPath();
  pts.forEach((p, i) => {
    const x = i / (pts.length - 1) * (W - 2) + 1;
    const y = H - 2 - (p.v - lo) / (hi - lo) * (H - 4);
    i ? g.lineTo(x, y) : g.moveTo(x, y);
  });
  g.stroke();
}

function drawChart(cv, pts, units) {
  const dpr = devicePixelRatio || 1;
  const W = cv.clientWidth || 800, H = 280;
  cv.width = W * dpr; cv.height = H * dpr;
  const g = cv.getContext("2d");
  g.scale(dpr, dpr);
  g.font = "11px ui-monospace, monospace";
  const padL = 56, padR = 12, padT = 10, padB = 24;
  const iw = W - padL - padR, ih = H - padT - padB;
  if (!pts || pts.length === 0) {
    g.fillStyle = "#8B95A7"; g.fillText(t("no_data"), W / 2 - 50, H / 2);
    return;
  }
  const vs = pts.map(p => p.v);
  let lo = Math.min(...vs), hi = Math.max(...vs);
  if (hi === lo) { hi += 1; lo -= 1; }
  const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const t0 = pts[0].t, t1 = pts[pts.length - 1].t || t0 + 1;
  const X = t => padL + (t - t0) / (t1 - t0 || 1) * iw;
  const Y = v => padT + (1 - (v - lo) / (hi - lo)) * ih;
  // grid + y labels
  g.strokeStyle = "#232B38"; g.fillStyle = "#8B95A7"; g.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const v = lo + (hi - lo) * i / 4, y = Y(v);
    g.beginPath(); g.moveTo(padL, y); g.lineTo(W - padR, y); g.stroke();
    g.fillText(fmtVal(String(v), units).slice(0, 9), 4, y + 4);
  }
  // x labels
  const span = t1 - t0;
  for (let i = 0; i <= 4; i++) {
    const t = t0 + span * i / 4;
    const d = new Date(t * 1000);
    const lbl = span > 86400 * 2
      ? `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, "0")}:00`
      : `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
    g.fillText(lbl, X(t) - 18, H - 8);
  }
  // area + line
  g.beginPath();
  pts.forEach((p, i) => i ? g.lineTo(X(p.t), Y(p.v)) : g.moveTo(X(p.t), Y(p.v)));
  g.strokeStyle = "#E8A33D"; g.lineWidth = 1.6; g.stroke();
  g.lineTo(X(t1), Y(lo)); g.lineTo(X(t0), Y(lo)); g.closePath();
  g.fillStyle = "rgba(232,163,61,.10)"; g.fill();
}

// ---- modal ----
function modal(...kids) {
  const root = $("#modal-root");
  root.innerHTML = "";
  const close = () => (root.innerHTML = "");
  const box = el("div", { class: "modal" },
    el("button", { class: "modal-close ghost", onclick: close }, "✕"),
    ...kids);
  const ov = el("div", { class: "overlay", onclick: e => { if (e.target === ov) close(); } }, box);
  root.append(ov);
  return close;
}

// ---- beam / clock ----
async function refreshBeam() {
  try {
    const o = await api("/api/overview");
    const b = $("#beam");
    b.className = "beam " + (o.problems === 0 ? "sev-ok" : "sev-" + Math.max(1, o.worst));
  } catch (e) { /* ignore */ }
}
setInterval(refreshBeam, 15000);
setInterval(() => { $("#clock").textContent = new Date().toLocaleTimeString(loc()); }, 1000);

// ---- pages ----
const pages = { dashboard, hosts, data, problems, templates, settings };
let pageTimer = null;

async function route() {
  const name = (location.hash || "#dashboard").slice(1).split("/")[0];
  const fn = pages[name] || dashboard;
  document.querySelectorAll(".side a").forEach(a =>
    a.classList.toggle("on", a.dataset.page === name));
  clearInterval(pageTimer);
  main.innerHTML = "";
  try { await fn(); } catch (e) { main.append(el("div", { class: "panel err" }, String(e.message || e))); }
  refreshBeam();
}
window.addEventListener("hashchange", route);

// ---------- dashboard ----------
async function dashboard() {
  const render = async () => {
    const [o, probs, hostsList] = await Promise.all([
      api("/api/overview"), api("/api/problems").then(x => x || []), api("/api/hosts").then(x => x || [])]);
    const box = el("div", {},
      el("h1", {}, t("page_dashboard"), el("small", {}, "DASHBOARD")),
      el("div", { class: "hero" },
        el("span", { class: "big " + (o.problems ? "alert" : "calm") }, String(o.problems)),
        el("span", { class: "label" }, o.problems ? t("hero_problems") : t("hero_ok"))),
      el("div", { class: "statgrid" },
        el("div", { class: "stat" }, el("div", { class: "v" }, String(o.hosts)), el("div", { class: "k" }, t("hosts"))),
        el("div", { class: "stat" }, el("div", { class: "v" }, String(o.items)), el("div", { class: "k" }, t("stat_items")))),
    );
    if (probs.length) {
      box.append(el("div", { class: "panel" }, el("h2", {}, t("panel_active_problems")),
        ...probs.map(probRow)));
    } else {
      box.append(el("div", { class: "panel" },
        el("div", { class: "allclear" }, el("span", { class: "kanji" }, "静"), t("allclear_dash"))));
    }
    box.append(el("div", { class: "panel" }, el("h2", {}, t("hosts")),
      hostsList.length
        ? el("div", { class: "hostgrid" }, hostsList.map(h =>
          el("div", { class: "hostcard", onclick: () => { location.hash = "#data/" + h.id; } },
            el("div", { class: "hn" },
              el("span", { class: "dot " + (h.problem_count ? "d" + h.worst_sev : "ok") }), h.name),
            el("div", { class: "hm" }, h.addr || t("push_only"), " · ", String(h.item_count), " items"))))
        : el("div", { class: "dim" }, t("no_hosts_hint"))));
    main.innerHTML = ""; main.append(box);
  };
  await render();
  pageTimer = setInterval(render, 10000);
}

function probRow(p) {
  const r = el("div", { class: "prob p" + p.severity + (p.end ? " resolved" : "") },
    el("span", { class: "sev sev-" + p.severity }, sevName(p.severity)),
    el("span", { class: "ph" }, p.host),
    el("span", {}, p.name),
    el("span", { class: "pt" }, p.end ? `${fmtTime(p.start)} → ${fmtTime(p.end)}` : fmtTime(p.start) + "（" + ago(p.start) + "）"));
  return r;
}

// ---------- hosts ----------
async function hosts() {
  const [hostsList, tpls] = await Promise.all([api("/api/hosts"), api("/api/templates")]);
  const box = el("div", {},
    el("h1", {}, t("hosts"), el("small", {}, "HOSTS")),
    el("div", { class: "sub" }, t("hosts_sub")));

  // add form
  const nameI = el("input", { placeholder: t("ph_hostname"), class: "grow" });
  const addrI = el("input", { placeholder: t("ph_addr"), class: "grow" });
  const tplSel = el("select", { multiple: "", size: "1", title: t("tpl_multi") },
    tpls.map(t => el("option", { value: t.name }, t.name)));
  const commI = el("input", { placeholder: t("ph_community"), class: "grow" });
  const sportI = el("input", { placeholder: t("ph_snmpport"), style: "width:9em" });
  box.append(el("div", { class: "panel" }, el("h2", {}, t("add_host")),
    el("div", { class: "row" }, nameI, addrI),
    el("div", { class: "row" }, commI, sportI),
    el("div", { class: "row" }, tplSel,
      el("button", {
        class: "primary", onclick: async () => {
          const sel = [...tplSel.selectedOptions].map(o => o.value);
          try {
            const body = { name: nameI.value.trim(), addr: addrI.value.trim(), templates: sel };
            if (commI.value.trim()) body.snmp_community = commI.value.trim();
            const sp = parseInt(sportI.value, 10); if (sp) body.snmp_port = sp;
            await api("/api/hosts", { method: "POST", body });
            toast(t("toast_host_added")); route();
          } catch (e) { toast(e.message, true); }
        }
      }, t("btn_add")))));

  for (const h of hostsList) box.append(hostDetail(h, tpls));
  main.append(box);
}

function hostDetail(h, tpls) {
  const det = el("details", { class: "hostdet" });
  const sum = el("summary", {},
    el("span", { class: "dot " + (h.problem_count ? "d" + h.worst_sev : "ok") }),
    el("strong", {}, h.name),
    el("span", { class: "mono dim" }, h.addr || t("push_only")),
    el("span", { class: "dim" }, t("items_label", h.item_count)),
    el("span", { class: "tplchips" }, h.templates.map(tn =>
      el("span", { class: "chip" }, tn, el("button", {
        title: t("tpl_unlink_title"), onclick: async e => {
          e.preventDefault();
          if (!confirm(t("confirm_unlink", tn))) return;
          await api(`/api/hosts/${h.id}/unlink`, { method: "POST", body: { template: tn } });
          toast(t("toast_unlinked")); route();
        }
      }, "✕")))),
    el("button", {
      class: "danger", style: "margin-left:auto", onclick: async e => {
        e.preventDefault();
        if (!confirm(t("confirm_del_host", h.name))) return;
        await api("/api/hosts/" + h.id, { method: "DELETE" });
        toast(t("toast_deleted")); route();
      }
    }, t("btn_delete")));
  det.append(sum);
  const body = el("div", { class: "body" });
  det.append(body);
  det.addEventListener("toggle", async () => {
    if (!det.open) return;
    body.innerHTML = t("loading");
    const [items, trigs] = await Promise.all([
      api("/api/items?host=" + h.id), api("/api/triggers?host=" + h.id)]);
    body.innerHTML = "";

    // link template
    const linkSel = el("select", {}, el("option", { value: "" }, t("tpl_link_opt")),
      tpls.filter(t => !h.templates.includes(t.name)).map(t => el("option", { value: t.name }, t.name)));
    linkSel.addEventListener("change", async () => {
      if (!linkSel.value) return;
      try {
        await api(`/api/hosts/${h.id}/link`, { method: "POST", body: { template: linkSel.value } });
        toast(t("toast_linked")); route();
      } catch (e) { toast(e.message, true); }
    });
    body.append(el("div", { class: "row" }, linkSel));

    // items table
    body.append(el("h4", {}, t("items_n", items.length)));
    const tb = el("table", {},
      el("tr", {}, el("th", {}, t("name")), el("th", {}, t("key_col")), el("th", {}, t("type_col")), el("th", {}, t("interval_col")), el("th", {}, t("state_col")), el("th", {}, "")),
      ...items.map(it => el("tr", {},
        el("td", {}, it.name, it.note ? el("div", { class: "err" }, it.note) : null),
        el("td", { class: "mono" }, it.key),
        el("td", { class: "mono dim" }, it.type),
        el("td", { class: "num dim" }, it.delay + "s"),
        el("td", {}, it.enabled
          ? (it.state.err ? el("span", { class: "err" }, it.state.err) : el("span", { class: "dim" }, t("state_ok")))
          : el("span", { class: "dim" }, t("state_disabled"))),
        el("td", {}, el("button", {
          class: "danger", onclick: async () => {
            if (!confirm(t("confirm_del_item", it.name))) return;
            await api("/api/items/" + it.id, { method: "DELETE" });
            det.open = false; det.open = true;
          }
        }, "✕")))));
    body.append(tb);

    // add item
    const inName = el("input", { placeholder: t("name") });
    const inKey = el("input", { placeholder: t("ph_key"), class: "grow mono" });
    const inType = el("select", {},
      el("option", { value: "passive" }, "passive"),
      el("option", { value: "active" }, "active"),
      el("option", { value: "trapper" }, "trapper"));
    const inVT = el("select", {}, el("option", { value: "float" }, t("vt_float")), el("option", { value: "text" }, t("vt_text")));
    const inDelay = el("input", { placeholder: "60", size: "4", title: t("interval_sec") });
    body.append(el("div", { class: "row" }, inName, inKey, inType, inVT, inDelay,
      el("button", {
        class: "primary", onclick: async () => {
          try {
            await api("/api/items", {
              method: "POST", body: {
                hostid: h.id, name: inName.value.trim(), key: inKey.value.trim(),
                type: inType.value, value_type: inVT.value, delay: parseInt(inDelay.value) || 60
              }
            });
            toast(t("toast_item_added")); det.open = false; det.open = true;
          } catch (e) { toast(e.message, true); }
        }
      }, t("btn_add"))));

    // triggers
    body.append(el("h4", {}, t("triggers_n", trigs.length)));
    body.append(el("table", {},
      el("tr", {}, el("th", {}, t("th_severity")), el("th", {}, t("name")), el("th", {}, t("th_expr")), el("th", {}, t("state_col")), el("th", {}, "")),
      ...trigs.map(trg => el("tr", {},
        el("td", {}, el("span", { class: "sev sev-" + trg.severity }, sevName(trg.severity))),
        el("td", {}, trg.name),
        el("td", { class: "mono", style: "word-break:break-all" }, trg.expression),
        el("td", {}, trg.err ? el("span", { class: "err", title: trg.err }, t("state_expr_err"))
          : (trg.active ? el("span", { class: "err" }, t("state_active")) : el("span", { class: "dim" }, t("state_ok")))),
        el("td", {}, el("button", {
          class: "danger", onclick: async () => {
            if (!confirm(t("confirm_del_trigger"))) return;
            await api("/api/triggers/" + trg.id, { method: "DELETE" });
            det.open = false; det.open = true;
          }
        }, "✕"))))));

    const trName = el("input", { placeholder: t("name") });
    const trExpr = el("input", { placeholder: t("ph_expr", h.name), class: "grow mono" });
    const trSev = el("select", {}, SEV.map((_, i) => el("option", { value: i }, sevName(i))));
    trSev.value = "2";
    body.append(el("div", { class: "row" }, trName, trExpr, trSev,
      el("button", {
        class: "primary", onclick: async () => {
          try {
            await api("/api/triggers", {
              method: "POST", body: {
                hostid: h.id, name: trName.value.trim(),
                expression: trExpr.value.trim(), severity: parseInt(trSev.value)
              }
            });
            toast(t("toast_trigger_added")); det.open = false; det.open = true;
          } catch (e) { toast(e.message, true); }
        }
      }, t("btn_add"))));
  });
  return det;
}

// ---------- latest data ----------
async function data() {
  const hostsList = await api("/api/hosts");
  const want = parseInt((location.hash.split("/")[1] || "0"), 10);
  const sel = el("select", {}, hostsList.map(h =>
    el("option", { value: h.id, selected: h.id === want ? "" : undefined }, h.name)));
  if (want && hostsList.some(h => h.id === want)) sel.value = String(want);
  const tableWrap = el("div", {});
  const box = el("div", {},
    el("h1", {}, t("page_data"), el("small", {}, "LATEST DATA")),
    el("div", { class: "row" }, sel),
    tableWrap);
  main.append(box);
  if (!hostsList.length) { tableWrap.append(el("div", { class: "panel dim" }, t("no_hosts"))); return; }

  const load = async () => {
    const hid = sel.value;
    const items = await api(`/api/items?host=${hid}&spark=1`);
    tableWrap.innerHTML = "";
    const tb = el("table", {},
      el("tr", {}, el("th", {}, t("th_item")), el("th", {}, t("th_lastval")), el("th", {}, t("th_updated")), el("th", {}, "1h")),
      ...items.filter(i => i.enabled).map(it => {
        const cv = el("canvas", { class: "spark" });
        const tr = el("tr", { class: it.value_type === "float" ? "click" : "" },
          el("td", {}, it.name, el("div", { class: "mono dim", style: "font-size:11px" }, it.key)),
          el("td", { class: "num" }, it.state.err
            ? el("span", { class: "err", title: it.state.err }, "ERR")
            : fmtVal(it.state.last_value, it.units)),
          el("td", { class: "dim num" }, ago(it.state.last_time)),
          el("td", {}, cv));
        if (it.value_type === "float") tr.addEventListener("click", () => chartModal(it));
        queueMicrotask(() => drawSpark(cv, it.spark));
        return tr;
      }));
    tableWrap.append(el("div", { class: "panel" }, tb));
  };
  sel.addEventListener("change", load);
  await load();
  pageTimer = setInterval(load, 15000);
}

function chartModal(it) {
  const cv = el("canvas", { class: "chart" });
  const ranges = [["1h", 3600], ["6h", 21600], ["24h", 86400], ["7d", 604800]];
  let cur = 3600;
  const btns = ranges.map(([lbl, sec]) =>
    el("button", {
      class: sec === cur ? "on" : "", onclick: async e => {
        cur = sec;
        btns.forEach(b => b.classList.remove("on"));
        e.target.classList.add("on");
        await draw();
      }
    }, lbl));
  async function draw() {
    const now = Math.floor(Date.now() / 1000);
    const pts = await api(`/api/history?item=${it.id}&from=${now - cur}&to=${now}`);
    drawChart(cv, pts, it.units);
  }
  modal(el("h3", {}, it.name),
    el("div", { class: "mk" }, it.key),
    el("div", { class: "ranges" }, btns),
    el("div", { class: "chartwrap" }, cv));
  requestAnimationFrame(draw);
}

// ---------- problems ----------
async function problems() {
  let showAll = false;
  const wrap = el("div", {});
  const tgl = el("button", { class: "ghost" }, t("show_history"));
  tgl.addEventListener("click", () => { showAll = !showAll; tgl.textContent = showAll ? t("show_active") : t("show_history"); load(); });
  main.append(el("div", {},
    el("h1", {}, t("page_problems"), el("small", {}, "PROBLEMS")),
    el("div", { class: "row" }, tgl), wrap));
  const load = async () => {
    const ps = (await api("/api/problems" + (showAll ? "?all=1" : ""))) || [];
    wrap.innerHTML = "";
    if (!ps.length) {
      wrap.append(el("div", { class: "panel" },
        el("div", { class: "allclear" }, el("span", { class: "kanji" }, "静"), t("no_problems"))));
      return;
    }
    wrap.append(...ps.map(probRow));
  };
  await load();
  pageTimer = setInterval(load, 10000);
}

// ---------- templates ----------
async function templates() {
  const tpls = await api("/api/templates");
  const ta = el("textarea", { placeholder: t("ph_tpl_paste") });
  const file = el("input", { type: "file", accept: ".json" });
  file.addEventListener("change", async () => {
    if (file.files[0]) ta.value = await file.files[0].text();
  });
  const doImport = async () => {
    try {
      const res = await api("/api/templates/import", { method: "POST", body: ta.value });
      let msg = t("toast_import", res.templates.join(", "), res.items, res.triggers);
      if (res.skipped && res.skipped.length) msg += t("toast_skip", res.skipped.length);
      toast(msg);
      if (res.skipped && res.skipped.length)
        modal(el("h3", {}, t("import_result")), el("div", { class: "mk" }, t("import_skipped_msg")),
          el("ul", {}, res.skipped.map(s => el("li", { class: "mono", style: "font-size:12px;margin-bottom:4px" }, s))));
      route();
    } catch (e) { toast(e.message, true); }
  };
  main.append(el("div", {},
    el("h1", {}, t("page_templates"), el("small", {}, "TEMPLATES")),
    el("div", { class: "sub" }, t("tpl_sub")),
    el("div", { class: "panel" }, el("h2", {}, t("import")),
      el("div", { class: "row" }, file),
      ta,
      el("div", { class: "row", style: "margin-top:10px" },
        el("button", { class: "primary", onclick: doImport }, t("import")))),
    el("div", { class: "panel" }, el("h2", {}, t("registered_tpls")),
      tpls.length ? el("table", {},
        el("tr", {}, el("th", {}, t("name")), el("th", {}, "items"), el("th", {}, "triggers"), el("th", {}, "")),
        ...tpls.map(tp => el("tr", {},
          el("td", {}, tp.name),
          el("td", { class: "num" }, String(tp.items)),
          el("td", { class: "num" }, String(tp.triggers)),
          el("td", {}, el("button", {
            class: "danger", onclick: async () => {
              if (!confirm(t("confirm_del_tpl", tp.name))) return;
              await api("/api/templates/" + encodeURIComponent(tp.name), { method: "DELETE" });
              toast(t("toast_deleted")); route();
            }
          }, "✕")))))
        : el("div", { class: "dim" }, t("no_tpls")))));
}

// ---------- settings ----------
async function settings() {
  const s = await api("/api/settings");
  const url = el("input", { class: "grow mono", placeholder: "https://discord.com/api/webhooks/…", value: s.webhook_url || "" });
  const typ = el("select", {},
    el("option", { value: "discord", selected: s.webhook_type !== "generic" ? "" : undefined }, "Discord"),
    el("option", { value: "generic", selected: s.webhook_type === "generic" ? "" : undefined }, t("generic_json")));
  const ret = el("input", { class: "num", size: "5", value: String(s.retention_days || 90) });
  const unr = el("input", { class: "num", size: "6", value: String(s.unreachable_sec || 0) });
  main.append(el("div", {},
    el("h1", {}, t("page_settings"), el("small", {}, "SETTINGS")),
    el("div", { class: "panel" }, el("h2", {}, t("notif_webhook")),
      el("div", { class: "row" }, typ, url),
      el("div", { class: "row" },
        el("button", {
          class: "primary", onclick: async () => {
            await api("/api/settings", {
              method: "PUT", body: {
                webhook_url: url.value.trim(), webhook_type: typ.value,
                retention_days: parseInt(ret.value) || 90,
                unreachable_sec: parseInt(unr.value) || 0
              }
            });
            toast(t("toast_saved"));
          }
        }, t("btn_save")),
        el("button", {
          class: "ghost", onclick: async () => {
            await api("/api/test-alert", { method: "POST" });
            toast(t("toast_test_sent"));
          }
        }, t("btn_test_notif")))),
    el("div", { class: "panel" }, el("h2", {}, t("data_retention")),
      el("div", { class: "row" }, ret, el("span", { class: "dim" }, t("retention_unit"))),
      el("div", { class: "dim", style: "font-size:12px" }, t("retention_note"))),
    el("div", { class: "panel" }, el("h2", {}, t("avail_title")),
      el("div", { class: "row" }, el("span", { class: "dim" }, t("unreachable_label")), unr),
      el("div", { class: "dim", style: "font-size:12px" }, t("unreachable_help")))));
}

// ---- boot ----
function buildLangSwitch() {
  const box = $("#langsw");
  if (!box) return;
  const cur = lang();
  box.innerHTML = "";
  [["en", "EN"], ["ja", "日本語"]].forEach(([code, label]) => {
    box.append(el("button", {
      class: "langbtn" + (code === cur ? " on" : ""),
      onclick: () => {
        if (code === cur) return;
        localStorage.setItem("yagura_lang", code);
        location.reload();
      }
    }, label));
  });
}

async function boot() {
  document.documentElement.lang = lang();
  try { T = await (await fetch("i18n/" + lang() + ".json")).json(); }
  catch (e) { T = {}; }
  buildLangSwitch();
  route();
}
boot();
