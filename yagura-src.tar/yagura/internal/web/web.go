package web

import (
	"crypto/subtle"
	"embed"
	"encoding/json"
	"io"
	"io/fs"
	"net/http"
	"strconv"
	"strings"
	"time"

	"yagura/internal/store"
	"yagura/internal/tpl"
	"yagura/internal/trigger"
)

//go:embed static
var staticFS embed.FS

type Server struct {
	St     *store.Store
	Eng    *trigger.Engine
	Token  string // optional bearer token; empty = no auth
	Listen string
}

func (s *Server) Run() error {
	mux := http.NewServeMux()

	sub, _ := fs.Sub(staticFS, "static")
	mux.Handle("GET /", http.FileServer(http.FS(sub)))

	mux.HandleFunc("GET /api/overview", s.overview)

	mux.HandleFunc("GET /api/hosts", s.hostsGet)
	mux.HandleFunc("POST /api/hosts", s.hostAdd)
	mux.HandleFunc("PUT /api/hosts/{id}", s.hostUpdate)
	mux.HandleFunc("DELETE /api/hosts/{id}", s.hostDelete)
	mux.HandleFunc("POST /api/hosts/{id}/link", s.hostLink)
	mux.HandleFunc("POST /api/hosts/{id}/unlink", s.hostUnlink)

	mux.HandleFunc("GET /api/items", s.itemsGet)
	mux.HandleFunc("POST /api/items", s.itemAdd)
	mux.HandleFunc("PUT /api/items/{id}", s.itemUpdate)
	mux.HandleFunc("DELETE /api/items/{id}", s.itemDelete)
	mux.HandleFunc("GET /api/history", s.history)

	mux.HandleFunc("GET /api/triggers", s.triggersGet)
	mux.HandleFunc("POST /api/triggers", s.triggerAdd)
	mux.HandleFunc("DELETE /api/triggers/{id}", s.triggerDelete)

	mux.HandleFunc("GET /api/problems", s.problems)

	mux.HandleFunc("GET /api/templates", s.templatesGet)
	mux.HandleFunc("POST /api/templates/import", s.templateImport)
	mux.HandleFunc("DELETE /api/templates/{name}", s.templateDelete)

	mux.HandleFunc("GET /api/settings", s.settingsGet)
	mux.HandleFunc("PUT /api/settings", s.settingsPut)
	mux.HandleFunc("POST /api/test-alert", s.testAlert)

	return http.ListenAndServe(s.Listen, s.auth(mux))
}

func (s *Server) auth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if s.Token != "" && strings.HasPrefix(r.URL.Path, "/api/") {
			got := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
			if subtle.ConstantTimeCompare([]byte(got), []byte(s.Token)) != 1 {
				http.Error(w, `{"error":"unauthorized"}`, http.StatusUnauthorized)
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}

func jsonOK(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func jsonErr(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}

func pathID(r *http.Request) int64 {
	id, _ := strconv.ParseInt(r.PathValue("id"), 10, 64)
	return id
}

// ---- handlers ----

func (s *Server) overview(w http.ResponseWriter, r *http.Request) {
	hosts := s.St.Hosts()
	probs := s.St.Problems(true, 0)
	worst := -1
	for _, p := range probs {
		if p.Severity > worst {
			worst = p.Severity
		}
	}
	itemCount, dataPoints := 0, 0
	for _, it := range s.St.Items(0) {
		if it.Enabled {
			itemCount++
		}
		_ = it
		dataPoints++
	}
	jsonOK(w, map[string]any{
		"hosts": len(hosts), "items": itemCount,
		"problems": len(probs), "worst": worst,
		"time": time.Now().Unix(),
	})
}

type hostView struct {
	*store.Host
	ItemCount    int `json:"item_count"`
	ProblemCount int `json:"problem_count"`
	WorstSev     int `json:"worst_sev"`
}

func (s *Server) hostsGet(w http.ResponseWriter, r *http.Request) {
	probs := s.St.Problems(true, 0)
	out := []hostView{}
	for _, h := range s.St.Hosts() {
		v := hostView{Host: h, WorstSev: -1}
		v.ItemCount = len(s.St.Items(h.ID))
		for _, p := range probs {
			if p.HostID == h.ID {
				v.ProblemCount++
				if p.Severity > v.WorstSev {
					v.WorstSev = p.Severity
				}
			}
		}
		out = append(out, v)
	}
	jsonOK(w, out)
}

func (s *Server) hostAdd(w http.ResponseWriter, r *http.Request) {
	var h store.Host
	if err := json.NewDecoder(r.Body).Decode(&h); err != nil || h.Name == "" {
		jsonErr(w, 400, "name is required")
		return
	}
	if _, dup := s.St.HostByName(h.Name); dup {
		jsonErr(w, 409, "host name already exists")
		return
	}
	h.Enabled = true
	tpls := h.Templates
	h.Templates = nil
	added := s.St.AddHost(&h)
	for _, t := range tpls {
		s.St.LinkTemplate(added.ID, t)
	}
	hh, _ := s.St.Host(added.ID)
	jsonOK(w, hh)
}

func (s *Server) hostUpdate(w http.ResponseWriter, r *http.Request) {
	var h store.Host
	if err := json.NewDecoder(r.Body).Decode(&h); err != nil {
		jsonErr(w, 400, err.Error())
		return
	}
	h.ID = pathID(r)
	if !s.St.UpdateHost(&h) {
		jsonErr(w, 404, "host not found")
		return
	}
	jsonOK(w, h)
}

func (s *Server) hostDelete(w http.ResponseWriter, r *http.Request) {
	s.St.DeleteHost(pathID(r))
	jsonOK(w, map[string]bool{"ok": true})
}

func (s *Server) hostLink(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Template string `json:"template"`
	}
	json.NewDecoder(r.Body).Decode(&body)
	if err := s.St.LinkTemplate(pathID(r), body.Template); err != nil {
		jsonErr(w, 400, err.Error())
		return
	}
	jsonOK(w, map[string]bool{"ok": true})
}

func (s *Server) hostUnlink(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Template string `json:"template"`
	}
	json.NewDecoder(r.Body).Decode(&body)
	s.St.UnlinkTemplate(pathID(r), body.Template)
	jsonOK(w, map[string]bool{"ok": true})
}

type itemView struct {
	*store.Item
	State *store.ItemState `json:"state"`
	Spark []store.Point    `json:"spark,omitempty"`
}

func (s *Server) itemsGet(w http.ResponseWriter, r *http.Request) {
	hostID, _ := strconv.ParseInt(r.URL.Query().Get("host"), 10, 64)
	withSpark := r.URL.Query().Get("spark") == "1"
	out := []itemView{}
	from := time.Now().Add(-time.Hour).Unix()
	for _, it := range s.St.Items(hostID) {
		v := itemView{Item: it, State: s.St.ItemState(it.ID)}
		if withSpark && it.ValueType == store.VFloat {
			pts := s.St.TS.Recent(it.ID, from)
			if len(pts) > 60 {
				pts = pts[len(pts)-60:]
			}
			v.Spark = pts
		}
		out = append(out, v)
	}
	jsonOK(w, out)
}

func (s *Server) itemAdd(w http.ResponseWriter, r *http.Request) {
	var it store.Item
	if err := json.NewDecoder(r.Body).Decode(&it); err != nil || it.Key == "" || it.HostID == 0 {
		jsonErr(w, 400, "hostid and key are required")
		return
	}
	if it.Name == "" {
		it.Name = it.Key
	}
	if it.Type == "" {
		it.Type = store.Passive
	}
	if it.ValueType == "" {
		it.ValueType = store.VFloat
	}
	if it.DelaySec <= 0 {
		it.DelaySec = 60
	}
	it.Enabled = true
	jsonOK(w, s.St.AddItem(&it))
}

func (s *Server) itemUpdate(w http.ResponseWriter, r *http.Request) {
	var it store.Item
	if err := json.NewDecoder(r.Body).Decode(&it); err != nil {
		jsonErr(w, 400, err.Error())
		return
	}
	it.ID = pathID(r)
	if !s.St.UpdateItem(&it) {
		jsonErr(w, 404, "item not found")
		return
	}
	jsonOK(w, it)
}

func (s *Server) itemDelete(w http.ResponseWriter, r *http.Request) {
	s.St.DeleteItem(pathID(r))
	jsonOK(w, map[string]bool{"ok": true})
}

func (s *Server) history(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	id, _ := strconv.ParseInt(q.Get("item"), 10, 64)
	now := time.Now().Unix()
	from, _ := strconv.ParseInt(q.Get("from"), 10, 64)
	to, _ := strconv.ParseInt(q.Get("to"), 10, 64)
	if from == 0 {
		from = now - 3600
	}
	if to == 0 {
		to = now
	}
	pts := s.St.TS.Range(id, from, to, 800)
	if pts == nil {
		pts = []store.Point{}
	}
	jsonOK(w, pts)
}

type trigView struct {
	*store.Trigger
	Err    string `json:"err,omitempty"`
	Active bool   `json:"active"`
}

func (s *Server) triggersGet(w http.ResponseWriter, r *http.Request) {
	hostID, _ := strconv.ParseInt(r.URL.Query().Get("host"), 10, 64)
	out := []trigView{}
	for _, tr := range s.St.Triggers(hostID) {
		v := trigView{Trigger: tr, Err: s.Eng.TriggerError(tr.ID)}
		_, v.Active = s.St.ActiveProblem(tr.ID)
		out = append(out, v)
	}
	jsonOK(w, out)
}

func (s *Server) triggerAdd(w http.ResponseWriter, r *http.Request) {
	var tr store.Trigger
	if err := json.NewDecoder(r.Body).Decode(&tr); err != nil || tr.Expression == "" || tr.HostID == 0 {
		jsonErr(w, 400, "hostid and expression are required")
		return
	}
	if _, err := trigger.Parse(tr.Expression); err != nil {
		jsonErr(w, 400, "expression: "+err.Error())
		return
	}
	if tr.Name == "" {
		tr.Name = tr.Expression
	}
	tr.Enabled = true
	jsonOK(w, s.St.AddTrigger(&tr))
}

func (s *Server) triggerDelete(w http.ResponseWriter, r *http.Request) {
	s.St.DeleteTrigger(pathID(r))
	jsonOK(w, map[string]bool{"ok": true})
}

func (s *Server) problems(w http.ResponseWriter, r *http.Request) {
	active := r.URL.Query().Get("all") != "1"
	out := s.St.Problems(active, 200)
	if out == nil {
		out = []*store.Problem{}
	}
	jsonOK(w, out)
}

func (s *Server) templatesGet(w http.ResponseWriter, r *http.Request) {
	type tv struct {
		Name     string `json:"name"`
		Items    int    `json:"items"`
		Triggers int    `json:"triggers"`
	}
	out := []tv{}
	for _, t := range s.St.Templates() {
		out = append(out, tv{Name: t.Name, Items: len(t.Items), Triggers: len(t.Triggers)})
	}
	jsonOK(w, out)
}

func (s *Server) templateImport(w http.ResponseWriter, r *http.Request) {
	raw, err := io.ReadAll(io.LimitReader(r.Body, 32<<20))
	if err != nil {
		jsonErr(w, 400, err.Error())
		return
	}
	res, err := tpl.Import(s.St, raw)
	if err != nil {
		jsonErr(w, 400, err.Error())
		return
	}
	jsonOK(w, res)
}

func (s *Server) templateDelete(w http.ResponseWriter, r *http.Request) {
	s.St.DeleteTemplate(r.PathValue("name"))
	jsonOK(w, map[string]bool{"ok": true})
}

func (s *Server) settingsGet(w http.ResponseWriter, r *http.Request) {
	jsonOK(w, s.St.Settings())
}

func (s *Server) settingsPut(w http.ResponseWriter, r *http.Request) {
	var st store.Settings
	if err := json.NewDecoder(r.Body).Decode(&st); err != nil {
		jsonErr(w, 400, err.Error())
		return
	}
	s.St.SetSettings(st)
	jsonOK(w, st)
}

func (s *Server) testAlert(w http.ResponseWriter, r *http.Request) {
	s.Eng.TestNotify()
	jsonOK(w, map[string]bool{"ok": true})
}
