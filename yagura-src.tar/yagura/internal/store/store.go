package store

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

type ItemType string

const (
	Passive ItemType = "passive" // server polls agent (port 10050)
	Active  ItemType = "active"  // agent pushes via active checks
	Trapper ItemType = "trapper" // zabbix_sender / external push
	SNMP    ItemType = "snmp"    // SNMP v1/v2c GET (port 161)
)

type ValueType string

const (
	VFloat ValueType = "float"
	VText  ValueType = "text"
)

type Host struct {
	ID        int64    `json:"id"`
	Name      string   `json:"name"` // must match agent Hostname for active checks
	Addr      string   `json:"addr"` // host[:port] for passive polling
	Templates []string `json:"templates"`
	Enabled   bool     `json:"enabled"`
	// SNMP settings (used by items of type "snmp")
	SNMPCommunity string `json:"snmp_community,omitempty"` // default "public"
	SNMPPort      int    `json:"snmp_port,omitempty"`      // default 161
	SNMPVersion   int    `json:"snmp_version,omitempty"`   // 1 or 2 (=v2c, default)
}

// PreStep is one preprocessing step applied to incoming values.
// Supported types: MULTIPLIER (params = factor), CHANGE_PER_SECOND.
type PreStep struct {
	Type   string `json:"type"`
	Params string `json:"params,omitempty"`
}

type Item struct {
	ID        int64     `json:"id"`
	HostID    int64     `json:"hostid"`
	Name      string    `json:"name"`
	Key       string    `json:"key"`
	Type      ItemType  `json:"type"`
	ValueType ValueType `json:"value_type"`
	DelaySec  int       `json:"delay"`
	Units     string    `json:"units"`
	Template  string    `json:"template,omitempty"` // origin template name
	Enabled   bool      `json:"enabled"`
	Note      string    `json:"note,omitempty"`     // e.g. unsupported source type
	SNMPOID   string    `json:"snmp_oid,omitempty"` // for Type == SNMP
	Preproc   []PreStep `json:"preproc,omitempty"`
}

type Trigger struct {
	ID         int64  `json:"id"`
	HostID     int64  `json:"hostid"`
	Name       string `json:"name"`
	Expression string `json:"expression"`
	Severity   int    `json:"severity"` // 0..5
	Template   string `json:"template,omitempty"`
	Enabled    bool   `json:"enabled"`
}

type Problem struct {
	ID        int64  `json:"id"`
	TriggerID int64  `json:"triggerid"`
	HostID    int64  `json:"hostid"`
	Host      string `json:"host"`
	Name      string `json:"name"`
	Severity  int    `json:"severity"`
	Start     int64  `json:"start"`
	End       int64  `json:"end"` // 0 = active
}

type TplItem struct {
	Name      string    `json:"name"`
	Key       string    `json:"key"`
	Type      ItemType  `json:"type"`
	ValueType ValueType `json:"value_type"`
	DelaySec  int       `json:"delay"`
	Units     string    `json:"units"`
	Enabled   bool      `json:"enabled"`
	Note      string    `json:"note,omitempty"`
	SNMPOID   string    `json:"snmp_oid,omitempty"`
	Preproc   []PreStep `json:"preproc,omitempty"`
}

type TplTrigger struct {
	Name       string `json:"name"`
	Expression string `json:"expression"` // contains /{TEMPLATE}/ host refs
	Severity   int    `json:"severity"`
}

type Template struct {
	Name     string       `json:"name"`
	Items    []TplItem    `json:"items"`
	Triggers []TplTrigger `json:"triggers"`
	Skipped  int          `json:"skipped"` // unsupported entries
}

type Settings struct {
	WebhookURL    string `json:"webhook_url"`
	WebhookType   string `json:"webhook_type"` // discord | generic
	RetentionDays int    `json:"retention_days"`
	// UnreachableSec is how long a host may go without any successful
	// poll before it is flagged unreachable. 0 = auto (derived per host
	// from the fastest item's interval).
	UnreachableSec int `json:"unreachable_sec"`
}

// ItemState is runtime-only (not persisted): latest value & health.
type ItemState struct {
	LastTime  int64  `json:"last_time"`
	LastValue string `json:"last_value"`
	Err       string `json:"err,omitempty"`
	// preprocessing state for CHANGE_PER_SECOND
	prevRaw float64
	prevT   int64
	prevSet bool
}

type meta struct {
	Hosts     map[int64]*Host      `json:"hosts"`
	Items     map[int64]*Item      `json:"items"`
	Triggers  map[int64]*Trigger   `json:"triggers"`
	Problems  map[int64]*Problem   `json:"problems"`
	Templates map[string]*Template `json:"templates"`
	Settings  Settings             `json:"settings"`
	NextID    int64                `json:"next_id"`
}

type Store struct {
	mu    sync.RWMutex
	m     meta
	state map[int64]*ItemState
	dir   string
	TS    *TSDB
	// OnValue is called after a value is ingested (item id, host id).
	OnValue func(it *Item)
}

func Open(dir string) (*Store, error) {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	ts, err := OpenTSDB(filepath.Join(dir, "ts"))
	if err != nil {
		return nil, err
	}
	s := &Store{dir: dir, TS: ts, state: map[int64]*ItemState{}}
	s.m = meta{
		Hosts: map[int64]*Host{}, Items: map[int64]*Item{},
		Triggers: map[int64]*Trigger{}, Problems: map[int64]*Problem{},
		Templates: map[string]*Template{},
		Settings:  Settings{WebhookType: "discord", RetentionDays: 90},
		NextID:    1,
	}
	b, err := os.ReadFile(filepath.Join(dir, "meta.json"))
	if err == nil {
		if err := json.Unmarshal(b, &s.m); err != nil {
			return nil, fmt.Errorf("meta.json broken: %w", err)
		}
	}
	// rebuild last-value state from TSDB rings
	for id, it := range s.m.Items {
		if p, ok := ts.Last(id); ok {
			st := &ItemState{LastTime: p.T}
			if it.ValueType == VFloat {
				st.LastValue = strconv.FormatFloat(p.V, 'f', -1, 64)
			} else {
				st.LastValue = p.S
			}
			s.state[id] = st
		}
	}
	return s, nil
}

func (s *Store) save() {
	b, _ := json.MarshalIndent(&s.m, "", " ")
	tmp := filepath.Join(s.dir, "meta.json.tmp")
	if err := os.WriteFile(tmp, b, 0o644); err == nil {
		os.Rename(tmp, filepath.Join(s.dir, "meta.json"))
	}
}

func (s *Store) nextID() int64 { id := s.m.NextID; s.m.NextID++; return id }

// ---- hosts ----

func (s *Store) Hosts() []*Host {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]*Host, 0, len(s.m.Hosts))
	for _, h := range s.m.Hosts {
		c := *h
		out = append(out, &c)
	}
	return out
}

func (s *Store) Host(id int64) (*Host, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	h, ok := s.m.Hosts[id]
	if !ok {
		return nil, false
	}
	c := *h
	return &c, true
}

func (s *Store) HostByName(name string) (*Host, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	for _, h := range s.m.Hosts {
		if h.Name == name {
			c := *h
			return &c, true
		}
	}
	return nil, false
}

func (s *Store) AddHost(h *Host) *Host {
	s.mu.Lock()
	defer s.mu.Unlock()
	h.ID = s.nextID()
	if h.Templates == nil {
		h.Templates = []string{}
	}
	s.m.Hosts[h.ID] = h
	s.save()
	c := *h
	return &c
}

func (s *Store) UpdateHost(h *Host) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	cur, ok := s.m.Hosts[h.ID]
	if !ok {
		return false
	}
	cur.Name, cur.Addr, cur.Enabled = h.Name, h.Addr, h.Enabled
	s.save()
	return true
}

func (s *Store) DeleteHost(id int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.m.Hosts, id)
	for iid, it := range s.m.Items {
		if it.HostID == id {
			delete(s.m.Items, iid)
			delete(s.state, iid)
			s.TS.Drop(iid)
		}
	}
	for tid, tr := range s.m.Triggers {
		if tr.HostID == id {
			delete(s.m.Triggers, tid)
		}
	}
	for pid, p := range s.m.Problems {
		if p.HostID == id {
			delete(s.m.Problems, pid)
		}
	}
	s.save()
}

// ---- items ----

func (s *Store) Items(hostID int64) []*Item {
	s.mu.RLock()
	defer s.mu.RUnlock()
	var out []*Item
	for _, it := range s.m.Items {
		if hostID == 0 || it.HostID == hostID {
			c := *it
			out = append(out, &c)
		}
	}
	return out
}

func (s *Store) Item(id int64) (*Item, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	it, ok := s.m.Items[id]
	if !ok {
		return nil, false
	}
	c := *it
	return &c, true
}

func (s *Store) ItemByKey(hostID int64, key string) (*Item, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	for _, it := range s.m.Items {
		if it.HostID == hostID && it.Key == key {
			c := *it
			return &c, true
		}
	}
	return nil, false
}

func (s *Store) AddItem(it *Item) *Item {
	s.mu.Lock()
	defer s.mu.Unlock()
	it.ID = s.nextID()
	s.m.Items[it.ID] = it
	s.save()
	c := *it
	return &c
}

func (s *Store) UpdateItem(it *Item) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	cur, ok := s.m.Items[it.ID]
	if !ok {
		return false
	}
	cur.Name, cur.Key, cur.Type, cur.ValueType = it.Name, it.Key, it.Type, it.ValueType
	cur.DelaySec, cur.Units, cur.Enabled = it.DelaySec, it.Units, it.Enabled
	s.save()
	return true
}

func (s *Store) DeleteItem(id int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.m.Items, id)
	delete(s.state, id)
	s.TS.Drop(id)
	s.save()
}

func (s *Store) ItemState(id int64) *ItemState {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if st, ok := s.state[id]; ok {
		c := *st
		return &c
	}
	return &ItemState{}
}

// Availability summarizes a host's liveness from its server-polled items
// (passive / SNMP / active — the ones yagura initiates or whose cadence it
// knows). It returns the most recent successful sample time across those
// items, the smallest poll interval among them, and whether any such item
// exists. Trapper items are excluded because their cadence is arbitrary.
// This is the basis for server-side unreachable detection, which works
// regardless of whether the host's templates ship a nodata trigger.
func (s *Store) Availability(hostID int64) (lastSeen int64, minDelay int, has bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	minDelay = 1<<31 - 1
	for _, it := range s.m.Items {
		if it.HostID != hostID || !it.Enabled {
			continue
		}
		if it.Type != Passive && it.Type != SNMP && it.Type != Active {
			continue
		}
		has = true
		d := it.DelaySec
		if d <= 0 {
			d = 60
		}
		if d < minDelay {
			minDelay = d
		}
		if st, ok := s.state[it.ID]; ok && st.LastTime > lastSeen {
			lastSeen = st.LastTime
		}
	}
	if !has {
		minDelay = 0
	}
	return
}

func (s *Store) SetItemError(id int64, msg string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	st, ok := s.state[id]
	if !ok {
		st = &ItemState{}
		s.state[id] = st
	}
	st.Err = msg
}

// preprocess applies the item's preprocessing chain to a numeric value.
// Returns (value, keep). keep == false discards the sample (e.g. the first
// observation of a CHANGE_PER_SECOND counter, or a counter reset).
func (s *Store) preprocess(it *Item, t int64, v float64) (float64, bool) {
	s.mu.Lock()
	st, ok := s.state[it.ID]
	if !ok {
		st = &ItemState{}
		s.state[it.ID] = st
	}
	s.mu.Unlock()
	for _, step := range it.Preproc {
		switch step.Type {
		case "MULTIPLIER":
			f, err := strconv.ParseFloat(strings.TrimSpace(step.Params), 64)
			if err == nil {
				v *= f
			}
		case "CHANGE_PER_SECOND":
			s.mu.Lock()
			pr, pt, ps := st.prevRaw, st.prevT, st.prevSet
			st.prevRaw, st.prevT, st.prevSet = v, t, true
			s.mu.Unlock()
			if !ps || t <= pt {
				return 0, false
			}
			d := v - pr
			if d < 0 { // counter wrapped or device rebooted: drop sample
				return 0, false
			}
			v = d / float64(t-pt)
		}
	}
	return v, true
}

// Ingest parses a raw value for an item, stores it and fires OnValue.
func (s *Store) Ingest(it *Item, t int64, raw string) error {
	if t == 0 {
		t = time.Now().Unix()
	}
	p := Point{T: t}
	isStr := it.ValueType != VFloat
	if isStr {
		p.S = raw
	} else {
		v, err := strconv.ParseFloat(strings.TrimSpace(raw), 64)
		if err != nil {
			s.SetItemError(it.ID, "not a number: "+truncate(raw, 60))
			return err
		}
		if len(it.Preproc) > 0 {
			pv, keep := s.preprocess(it, t, v)
			if !keep {
				return nil // e.g. first sample of change-per-second
			}
			v = pv
		}
		p.V = v
	}
	s.TS.Append(it.ID, p, isStr)
	s.mu.Lock()
	st, ok := s.state[it.ID]
	if !ok {
		st = &ItemState{}
		s.state[it.ID] = st
	}
	st.LastTime, st.Err = t, ""
	if isStr {
		st.LastValue = raw
	} else {
		st.LastValue = strconv.FormatFloat(p.V, 'f', -1, 64)
	}
	cb := s.OnValue
	s.mu.Unlock()
	if cb != nil {
		cb(it)
	}
	return nil
}

// ---- triggers ----

func (s *Store) Triggers(hostID int64) []*Trigger {
	s.mu.RLock()
	defer s.mu.RUnlock()
	var out []*Trigger
	for _, tr := range s.m.Triggers {
		if hostID == 0 || tr.HostID == hostID {
			c := *tr
			out = append(out, &c)
		}
	}
	return out
}

func (s *Store) AddTrigger(tr *Trigger) *Trigger {
	s.mu.Lock()
	defer s.mu.Unlock()
	tr.ID = s.nextID()
	s.m.Triggers[tr.ID] = tr
	s.save()
	c := *tr
	return &c
}

func (s *Store) DeleteTrigger(id int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.m.Triggers, id)
	for pid, p := range s.m.Problems {
		if p.TriggerID == id && p.End == 0 {
			delete(s.m.Problems, pid)
		}
	}
	s.save()
}

// ---- problems ----

func (s *Store) ActiveProblem(triggerID int64) (*Problem, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	for _, p := range s.m.Problems {
		if p.TriggerID == triggerID && p.End == 0 {
			c := *p
			return &c, true
		}
	}
	return nil, false
}

func (s *Store) OpenProblem(tr *Trigger, hostName string) *Problem {
	s.mu.Lock()
	defer s.mu.Unlock()
	p := &Problem{ID: s.nextID(), TriggerID: tr.ID, HostID: tr.HostID,
		Host: hostName, Name: tr.Name, Severity: tr.Severity, Start: time.Now().Unix()}
	s.m.Problems[p.ID] = p
	s.save()
	c := *p
	return &c
}

func (s *Store) CloseProblem(id int64) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if p, ok := s.m.Problems[id]; ok {
		p.End = time.Now().Unix()
	}
	s.save()
}

// availTriggerID marks synthetic problems raised by server-side availability
// detection. Real triggers always have id >= 1, so 0 never collides.
const availTriggerID = 0

// ActiveHostDownProblem returns the open server-side "unreachable" problem
// for a host, if any.
func (s *Store) ActiveHostDownProblem(hostID int64) (*Problem, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	for _, p := range s.m.Problems {
		if p.TriggerID == availTriggerID && p.HostID == hostID && p.End == 0 {
			c := *p
			return &c, true
		}
	}
	return nil, false
}

// OpenHostDownProblem records that a host has stopped reporting.
func (s *Store) OpenHostDownProblem(h *Host, name string, severity int) *Problem {
	s.mu.Lock()
	defer s.mu.Unlock()
	p := &Problem{ID: s.nextID(), TriggerID: availTriggerID, HostID: h.ID,
		Host: h.Name, Name: name, Severity: severity, Start: time.Now().Unix()}
	s.m.Problems[p.ID] = p
	s.save()
	c := *p
	return &c
}

func (s *Store) Problems(activeOnly bool, limit int) []*Problem {
	s.mu.RLock()
	defer s.mu.RUnlock()
	var out []*Problem
	for _, p := range s.m.Problems {
		if activeOnly && p.End != 0 {
			continue
		}
		c := *p
		out = append(out, &c)
	}
	// newest first
	for i := 0; i < len(out); i++ {
		for j := i + 1; j < len(out); j++ {
			if out[j].Start > out[i].Start {
				out[i], out[j] = out[j], out[i]
			}
		}
	}
	if limit > 0 && len(out) > limit {
		out = out[:limit]
	}
	return out
}

// ---- templates ----

func (s *Store) Templates() []*Template {
	s.mu.RLock()
	defer s.mu.RUnlock()
	var out []*Template
	for _, t := range s.m.Templates {
		c := *t
		out = append(out, &c)
	}
	return out
}

func (s *Store) Template(name string) (*Template, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	t, ok := s.m.Templates[name]
	if !ok {
		return nil, false
	}
	c := *t
	return &c, true
}

func (s *Store) PutTemplate(t *Template) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.m.Templates[t.Name] = t
	s.save()
}

func (s *Store) DeleteTemplate(name string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.m.Templates, name)
	s.save()
}

// LinkTemplate materializes a template's items & triggers onto a host.
func (s *Store) LinkTemplate(hostID int64, tplName string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	h, ok := s.m.Hosts[hostID]
	if !ok {
		return fmt.Errorf("host %d not found", hostID)
	}
	t, ok := s.m.Templates[tplName]
	if !ok {
		return fmt.Errorf("template %q not found", tplName)
	}
	for _, lt := range h.Templates {
		if lt == tplName {
			return nil // already linked
		}
	}
	for _, ti := range t.Items {
		dup := false
		for _, it := range s.m.Items {
			if it.HostID == hostID && it.Key == ti.Key {
				dup = true
				break
			}
		}
		if dup {
			continue
		}
		it := &Item{ID: s.nextID(), HostID: hostID, Name: ti.Name, Key: ti.Key,
			Type: ti.Type, ValueType: ti.ValueType, DelaySec: ti.DelaySec,
			Units: ti.Units, Template: tplName, Enabled: ti.Enabled, Note: ti.Note,
			SNMPOID: ti.SNMPOID, Preproc: ti.Preproc}
		s.m.Items[it.ID] = it
	}
	for _, tt := range t.Triggers {
		expr := strings.ReplaceAll(tt.Expression, "/"+tplName+"/", "/"+h.Name+"/")
		name := strings.ReplaceAll(tt.Name, "{HOST.NAME}", h.Name)
		tr := &Trigger{ID: s.nextID(), HostID: hostID, Name: name,
			Expression: expr, Severity: tt.Severity, Template: tplName, Enabled: true}
		s.m.Triggers[tr.ID] = tr
	}
	h.Templates = append(h.Templates, tplName)
	s.save()
	return nil
}

// UnlinkTemplate removes template-derived items & triggers from a host.
func (s *Store) UnlinkTemplate(hostID int64, tplName string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	h, ok := s.m.Hosts[hostID]
	if !ok {
		return
	}
	for iid, it := range s.m.Items {
		if it.HostID == hostID && it.Template == tplName {
			delete(s.m.Items, iid)
			delete(s.state, iid)
			s.TS.Drop(iid)
		}
	}
	for tid, tr := range s.m.Triggers {
		if tr.HostID == hostID && tr.Template == tplName {
			delete(s.m.Triggers, tid)
		}
	}
	out := h.Templates[:0]
	for _, n := range h.Templates {
		if n != tplName {
			out = append(out, n)
		}
	}
	h.Templates = out
	s.save()
}

// ---- settings ----

func (s *Store) Settings() Settings {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.m.Settings
}

func (s *Store) SetSettings(st Settings) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if st.RetentionDays <= 0 {
		st.RetentionDays = 90
	}
	s.m.Settings = st
	s.save()
}

func truncate(s string, n int) string {
	if len(s) > n {
		return s[:n] + "…"
	}
	return s
}
