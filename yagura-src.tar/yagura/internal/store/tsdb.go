package store

import (
	"bufio"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// Point is a single sample. Numeric items use V, text items use S.
type Point struct {
	T int64   `json:"t"`
	V float64 `json:"v"`
	S string  `json:"s,omitempty"`
}

const ringCap = 4096

type series struct {
	mu    sync.Mutex
	ring  []Point // newest at the end
	f     *os.File
	isStr bool
}

// TSDB: numeric series are fixed 16-byte records (<id>.f64),
// text series are JSON-lines (<id>.txt). Recent points are mirrored
// in a ring buffer for trigger evaluation and sparklines.
type TSDB struct {
	dir string
	mu  sync.Mutex
	ss  map[int64]*series
}

func OpenTSDB(dir string) (*TSDB, error) {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, err
	}
	t := &TSDB{dir: dir, ss: map[int64]*series{}}
	ents, _ := os.ReadDir(dir)
	for _, e := range ents {
		var id int64
		name := e.Name()
		if n, err := fmt.Sscanf(name, "%d.f64", &id); err == nil && n == 1 && filepath.Ext(name) == ".f64" {
			t.open(id, false)
		} else if n, err := fmt.Sscanf(name, "%d.txt", &id); err == nil && n == 1 && filepath.Ext(name) == ".txt" {
			t.open(id, true)
		}
	}
	return t, nil
}

func (t *TSDB) path(id int64, isStr bool) string {
	ext := ".f64"
	if isStr {
		ext = ".txt"
	}
	return filepath.Join(t.dir, fmt.Sprintf("%d%s", id, ext))
}

// open (or create) a series and warm its ring from the file tail.
func (t *TSDB) open(id int64, isStr bool) *series {
	t.mu.Lock()
	if s, ok := t.ss[id]; ok {
		t.mu.Unlock()
		return s
	}
	s := &series{isStr: isStr}
	t.ss[id] = s
	t.mu.Unlock()

	f, err := os.OpenFile(t.path(id, isStr), os.O_CREATE|os.O_RDWR|os.O_APPEND, 0o644)
	if err != nil {
		return s
	}
	s.f = f
	if isStr {
		sc := bufio.NewScanner(f)
		sc.Buffer(make([]byte, 0, 1<<20), 1<<20)
		for sc.Scan() {
			var p Point
			if json.Unmarshal(sc.Bytes(), &p) == nil {
				s.push(p)
			}
		}
	} else {
		st, _ := f.Stat()
		recs := st.Size() / 16
		skip := int64(0)
		if recs > ringCap {
			skip = recs - ringCap
		}
		f.Seek(skip*16, io.SeekStart)
		buf := make([]byte, 16)
		for {
			if _, err := io.ReadFull(f, buf); err != nil {
				break
			}
			p := Point{
				T: int64(binary.LittleEndian.Uint64(buf[:8])),
			}
			p.V = float64frombits(binary.LittleEndian.Uint64(buf[8:]))
			s.push(p)
		}
		f.Seek(0, io.SeekEnd)
	}
	return s
}

func float64frombits(b uint64) float64 { return math.Float64frombits(b) }
func float64bits(f float64) uint64     { return math.Float64bits(f) }

func (s *series) push(p Point) {
	if len(s.ring) >= ringCap {
		copy(s.ring, s.ring[1:])
		s.ring[len(s.ring)-1] = p
	} else {
		s.ring = append(s.ring, p)
	}
}

func (t *TSDB) series(id int64) (*series, bool) {
	t.mu.Lock()
	defer t.mu.Unlock()
	s, ok := t.ss[id]
	return s, ok
}

func (t *TSDB) Append(id int64, p Point, isStr bool) {
	s, ok := t.series(id)
	if !ok {
		s = t.open(id, isStr)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.push(p)
	if s.f == nil {
		return
	}
	if s.isStr {
		b, _ := json.Marshal(p)
		s.f.Write(append(b, '\n'))
	} else {
		var buf [16]byte
		binary.LittleEndian.PutUint64(buf[:8], uint64(p.T))
		binary.LittleEndian.PutUint64(buf[8:], float64bits(p.V))
		s.f.Write(buf[:])
	}
}

// Last returns the most recent point.
func (t *TSDB) Last(id int64) (Point, bool) {
	s, ok := t.series(id)
	if !ok {
		return Point{}, false
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.ring) == 0 {
		return Point{}, false
	}
	return s.ring[len(s.ring)-1], true
}

// Recent returns ring-buffered points with T >= from (ascending).
func (t *TSDB) Recent(id int64, from int64) []Point {
	s, ok := t.series(id)
	if !ok {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	var out []Point
	for _, p := range s.ring {
		if p.T >= from {
			out = append(out, p)
		}
	}
	return out
}

// Range reads from disk for charting (numeric only; text falls back to ring).
func (t *TSDB) Range(id int64, from, to int64, maxPoints int) []Point {
	s, ok := t.series(id)
	if !ok {
		return nil
	}
	if s.isStr {
		var out []Point
		for _, p := range t.Recent(id, from) {
			if p.T <= to {
				out = append(out, p)
			}
		}
		return out
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	f, err := os.Open(t.path(id, false))
	if err != nil {
		return nil
	}
	defer f.Close()
	r := bufio.NewReaderSize(f, 1<<16)
	var out []Point
	buf := make([]byte, 16)
	for {
		if _, err := io.ReadFull(r, buf); err != nil {
			break
		}
		ts := int64(binary.LittleEndian.Uint64(buf[:8]))
		if ts < from || ts > to {
			continue
		}
		out = append(out, Point{T: ts, V: float64frombits(binary.LittleEndian.Uint64(buf[8:]))})
	}
	// decimate to maxPoints (simple stride)
	if maxPoints > 0 && len(out) > maxPoints {
		dec := make([]Point, 0, maxPoints)
		step := float64(len(out)) / float64(maxPoints)
		for i := 0; i < maxPoints; i++ {
			dec = append(dec, out[int(float64(i)*step)])
		}
		out = dec
	}
	return out
}

func (t *TSDB) Drop(id int64) {
	t.mu.Lock()
	s, ok := t.ss[id]
	delete(t.ss, id)
	t.mu.Unlock()
	if ok && s.f != nil {
		s.f.Close()
	}
	os.Remove(t.path(id, false))
	os.Remove(t.path(id, true))
}

// Retention rewrites series files dropping points older than cutoff.
func (t *TSDB) Retention(days int) {
	cutoff := time.Now().AddDate(0, 0, -days).Unix()
	t.mu.Lock()
	ids := make([]int64, 0, len(t.ss))
	for id := range t.ss {
		ids = append(ids, id)
	}
	t.mu.Unlock()
	for _, id := range ids {
		s, ok := t.series(id)
		if !ok {
			continue
		}
		s.mu.Lock()
		path := t.path(id, s.isStr)
		tmp := path + ".tmp"
		in, err := os.Open(path)
		if err != nil {
			s.mu.Unlock()
			continue
		}
		out, err := os.Create(tmp)
		if err != nil {
			in.Close()
			s.mu.Unlock()
			continue
		}
		w := bufio.NewWriter(out)
		if s.isStr {
			sc := bufio.NewScanner(in)
			sc.Buffer(make([]byte, 0, 1<<20), 1<<20)
			for sc.Scan() {
				var p Point
				if json.Unmarshal(sc.Bytes(), &p) == nil && p.T >= cutoff {
					w.Write(sc.Bytes())
					w.WriteByte('\n')
				}
			}
		} else {
			r := bufio.NewReaderSize(in, 1<<16)
			buf := make([]byte, 16)
			for {
				if _, err := io.ReadFull(r, buf); err != nil {
					break
				}
				if int64(binary.LittleEndian.Uint64(buf[:8])) >= cutoff {
					w.Write(buf)
				}
			}
		}
		w.Flush()
		out.Close()
		in.Close()
		if s.f != nil {
			s.f.Close()
		}
		os.Rename(tmp, path)
		s.f, _ = os.OpenFile(path, os.O_CREATE|os.O_RDWR|os.O_APPEND, 0o644)
		s.mu.Unlock()
	}
}
