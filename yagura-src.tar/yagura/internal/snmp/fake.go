package snmp

// Server-side helpers for the test harness (cmd/faker snmpagent).
// Not used by yagura itself.

// VB is a varbind value for BuildResponse.
type VB struct {
	Num    uint64
	Tag    byte // 0x41 Counter32, 0x42 Gauge32, 0x43 TimeTicks, 0x46 Counter64; 0 = Integer
	Str    string
	IsStr  bool
	NoSuch bool
}

// ParseGet extracts the request-id and OIDs from a GetRequest message.
func ParseGet(b []byte) (reqID int64, oids []string, ok bool) {
	r := &reader{b: b}
	tag, msg, err := r.readTLV()
	if err != nil || tag != tagSeq {
		return 0, nil, false
	}
	r = &reader{b: msg}
	if _, _, err = r.readTLV(); err != nil { // version
		return 0, nil, false
	}
	if _, _, err = r.readTLV(); err != nil { // community
		return 0, nil, false
	}
	tag, pdu, err := r.readTLV()
	if err != nil || tag != pduGet {
		return 0, nil, false
	}
	r = &reader{b: pdu}
	_, rid, err := r.readTLV()
	if err != nil {
		return 0, nil, false
	}
	reqID = decInt(rid)
	if _, _, err = r.readTLV(); err != nil { // error-status
		return 0, nil, false
	}
	if _, _, err = r.readTLV(); err != nil { // error-index
		return 0, nil, false
	}
	_, vbl, err := r.readTLV()
	if err != nil {
		return 0, nil, false
	}
	vr := &reader{b: vbl}
	for vr.pos < len(vr.b) {
		_, vb, err := vr.readTLV()
		if err != nil {
			return 0, nil, false
		}
		ir := &reader{b: vb}
		_, oidB, err := ir.readTLV()
		if err != nil {
			return 0, nil, false
		}
		oids = append(oids, decOID(oidB))
	}
	return reqID, oids, true
}

// BuildResponse encodes a GetResponse for the given request.
func BuildResponse(reqID int64, oids []string, vals map[string]VB) []byte {
	var vbs []byte
	for _, o := range oids {
		enc, err := encodeOID(o)
		if err != nil {
			continue
		}
		v := vals[o]
		var vb []byte
		switch {
		case v.NoSuch:
			vb = tlv(tagNoObject, nil)
		case v.IsStr:
			vb = tlv(tagOctStr, []byte(v.Str))
		case v.Tag != 0:
			vb = tlv(v.Tag, encUintTrim(v.Num))
		default:
			vb = tlv(tagInt, encInt(int(v.Num)))
		}
		vbs = append(vbs, tlv(tagSeq, append(enc, vb...))...)
	}
	pdu := tlv(pduResponse, concat(
		tlv(tagInt, encInt(int(reqID))),
		tlv(tagInt, encInt(0)),
		tlv(tagInt, encInt(0)),
		tlv(tagSeq, vbs),
	))
	return tlv(tagSeq, concat(
		tlv(tagInt, encInt(1)), // v2c
		tlv(tagOctStr, []byte("public")),
		pdu,
	))
}

func encUintTrim(v uint64) []byte {
	b := make([]byte, 9) // leading 0x00 so high-bit values stay unsigned
	for i := 8; i >= 1; i-- {
		b[i] = byte(v & 0xFF)
		v >>= 8
	}
	i := 0
	for i < 8 && b[i] == 0 && b[i+1]&0x80 == 0 {
		i++
	}
	return b[i:]
}
