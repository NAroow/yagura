// Package snmp implements a minimal SNMP v1/v2c GET client using only the
// standard library. Enough BER/ASN.1 is implemented to encode a GetRequest
// and decode the GetResponse varbinds.
package snmp

import (
	"encoding/binary"
	"fmt"
	"math/rand"
	"net"
	"strconv"
	"strings"
	"time"
	"unicode"
)

// ASN.1 / SNMP tags.
const (
	tagInt       = 0x02
	tagOctStr    = 0x04
	tagNull      = 0x05
	tagOID       = 0x06
	tagSeq       = 0x30
	tagIPAddr    = 0x40
	tagCounter32 = 0x41
	tagGauge32   = 0x42
	tagTimeTicks = 0x43
	tagOpaque    = 0x44
	tagCounter64 = 0x46
	tagNoObject  = 0x80 // noSuchObject
	tagNoInst    = 0x81 // noSuchInstance
	tagEndOfMib  = 0x82
	pduGet       = 0xA0
	pduResponse  = 0xA2
)

// Value is one decoded varbind value.
type Value struct {
	F     float64
	S     string
	IsStr bool
}

// Client issues SNMP GETs.
type Client struct {
	Addr      string // host:port (port 161 default appended by caller)
	Community string
	Version   int // 1 or 2 (v2c); default 2
	Timeout   time.Duration
	Retries   int
}

// Get fetches a single OID.
func (c *Client) Get(oid string) (*Value, error) {
	m, err := c.GetMulti([]string{oid})
	if err != nil {
		return nil, err
	}
	v, ok := m[normOID(oid)]
	if !ok {
		return nil, fmt.Errorf("no varbind for %s in response", oid)
	}
	return v, nil
}

// GetMulti fetches several OIDs in one request. Keys of the result map are
// normalized (no leading dot) OID strings.
func (c *Client) GetMulti(oids []string) (map[string]*Value, error) {
	if c.Timeout <= 0 {
		c.Timeout = 3 * time.Second
	}
	if c.Retries <= 0 {
		c.Retries = 1
	}
	if c.Community == "" {
		c.Community = "public"
	}
	ver := 1 // SNMPv2c on the wire
	if c.Version == 1 {
		ver = 0
	}
	reqID := int(rand.Int31() & 0x7FFFFFF)

	var vbs []byte
	for _, o := range oids {
		enc, err := encodeOID(normOID(o))
		if err != nil {
			return nil, fmt.Errorf("bad OID %q: %w", o, err)
		}
		vbs = append(vbs, tlv(tagSeq, append(enc, tlv(tagNull, nil)...))...)
	}
	pdu := tlv(pduGet, concat(
		tlv(tagInt, encInt(reqID)),
		tlv(tagInt, encInt(0)), // error-status
		tlv(tagInt, encInt(0)), // error-index
		tlv(tagSeq, vbs),
	))
	msg := tlv(tagSeq, concat(
		tlv(tagInt, encInt(ver)),
		tlv(tagOctStr, []byte(c.Community)),
		pdu,
	))

	var lastErr error
	for try := 0; try <= c.Retries; try++ {
		conn, err := net.DialTimeout("udp", c.Addr, c.Timeout)
		if err != nil {
			return nil, err
		}
		conn.SetDeadline(time.Now().Add(c.Timeout))
		if _, err = conn.Write(msg); err != nil {
			conn.Close()
			lastErr = err
			continue
		}
		buf := make([]byte, 65535)
		n, err := conn.Read(buf)
		conn.Close()
		if err != nil {
			lastErr = err
			continue
		}
		res, err := parseResponse(buf[:n], reqID)
		if err != nil {
			lastErr = err
			continue
		}
		return res, nil
	}
	return nil, lastErr
}

// ---- BER encode ----

func tlv(tag byte, content []byte) []byte {
	return append(append([]byte{tag}, encLen(len(content))...), content...)
}

func encLen(n int) []byte {
	if n < 128 {
		return []byte{byte(n)}
	}
	var b []byte
	for n > 0 {
		b = append([]byte{byte(n & 0xFF)}, b...)
		n >>= 8
	}
	return append([]byte{byte(0x80 | len(b))}, b...)
}

func encInt(v int) []byte {
	b := make([]byte, 8)
	binary.BigEndian.PutUint64(b, uint64(int64(v)))
	i := 0
	for i < 7 && ((b[i] == 0x00 && b[i+1]&0x80 == 0) || (b[i] == 0xFF && b[i+1]&0x80 != 0)) {
		i++
	}
	return b[i:]
}

func encodeOID(oid string) ([]byte, error) {
	parts := strings.Split(oid, ".")
	if len(parts) < 2 {
		return nil, fmt.Errorf("too short")
	}
	ids := make([]uint64, len(parts))
	for i, p := range parts {
		v, err := strconv.ParseUint(p, 10, 64)
		if err != nil {
			return nil, err
		}
		ids[i] = v
	}
	out := []byte{byte(ids[0]*40 + ids[1])}
	for _, id := range ids[2:] {
		out = append(out, encBase128(id)...)
	}
	return tlv(tagOID, out), nil
}

func encBase128(v uint64) []byte {
	if v == 0 {
		return []byte{0}
	}
	var b []byte
	for v > 0 {
		b = append([]byte{byte(v & 0x7F)}, b...)
		v >>= 7
	}
	for i := 0; i < len(b)-1; i++ {
		b[i] |= 0x80
	}
	return b
}

func concat(bs ...[]byte) []byte {
	var out []byte
	for _, b := range bs {
		out = append(out, b...)
	}
	return out
}

// ---- BER decode ----

type reader struct {
	b   []byte
	pos int
}

func (r *reader) readTLV() (tag byte, content []byte, err error) {
	if r.pos+2 > len(r.b) {
		return 0, nil, fmt.Errorf("truncated TLV")
	}
	tag = r.b[r.pos]
	r.pos++
	l := int(r.b[r.pos])
	r.pos++
	if l&0x80 != 0 {
		n := l & 0x7F
		if n == 0 || n > 4 || r.pos+n > len(r.b) {
			return 0, nil, fmt.Errorf("bad length")
		}
		l = 0
		for i := 0; i < n; i++ {
			l = l<<8 | int(r.b[r.pos])
			r.pos++
		}
	}
	if r.pos+l > len(r.b) {
		return 0, nil, fmt.Errorf("content overruns buffer")
	}
	content = r.b[r.pos : r.pos+l]
	r.pos += l
	return tag, content, nil
}

func decInt(b []byte) int64 {
	var v int64
	if len(b) > 0 && b[0]&0x80 != 0 {
		v = -1
	}
	for _, c := range b {
		v = v<<8 | int64(c)
	}
	return v
}

func decUint(b []byte) uint64 {
	var v uint64
	for _, c := range b {
		v = v<<8 | uint64(c)
	}
	return v
}

func decOID(b []byte) string {
	if len(b) == 0 {
		return ""
	}
	var sb strings.Builder
	fmt.Fprintf(&sb, "%d.%d", b[0]/40, b[0]%40)
	var v uint64
	for _, c := range b[1:] {
		v = v<<7 | uint64(c&0x7F)
		if c&0x80 == 0 {
			fmt.Fprintf(&sb, ".%d", v)
			v = 0
		}
	}
	return sb.String()
}

func parseResponse(b []byte, wantReqID int) (map[string]*Value, error) {
	r := &reader{b: b}
	tag, msg, err := r.readTLV()
	if err != nil || tag != tagSeq {
		return nil, fmt.Errorf("not an SNMP message")
	}
	r = &reader{b: msg}
	if _, _, err = r.readTLV(); err != nil { // version
		return nil, err
	}
	if _, _, err = r.readTLV(); err != nil { // community
		return nil, err
	}
	tag, pdu, err := r.readTLV()
	if err != nil {
		return nil, err
	}
	if tag != pduResponse {
		return nil, fmt.Errorf("unexpected PDU type 0x%02X", tag)
	}
	r = &reader{b: pdu}
	_, rid, err := r.readTLV()
	if err != nil {
		return nil, err
	}
	if int(decInt(rid)) != wantReqID {
		return nil, fmt.Errorf("request-id mismatch")
	}
	_, es, err := r.readTLV()
	if err != nil {
		return nil, err
	}
	if v := decInt(es); v != 0 {
		return nil, fmt.Errorf("SNMP error-status %d", v)
	}
	if _, _, err = r.readTLV(); err != nil { // error-index
		return nil, err
	}
	_, vbl, err := r.readTLV()
	if err != nil {
		return nil, err
	}
	out := map[string]*Value{}
	vr := &reader{b: vbl}
	for vr.pos < len(vr.b) {
		_, vb, err := vr.readTLV()
		if err != nil {
			return nil, err
		}
		ir := &reader{b: vb}
		_, oidB, err := ir.readTLV()
		if err != nil {
			return nil, err
		}
		vt, val, err := ir.readTLV()
		if err != nil {
			return nil, err
		}
		oid := decOID(oidB)
		v, err := convValue(vt, val)
		if err != nil {
			return nil, fmt.Errorf("%s: %w", oid, err)
		}
		out[oid] = v
	}
	return out, nil
}

func convValue(tag byte, b []byte) (*Value, error) {
	switch tag {
	case tagInt:
		return &Value{F: float64(decInt(b))}, nil
	case tagCounter32, tagGauge32, tagTimeTicks, tagCounter64:
		return &Value{F: float64(decUint(b))}, nil
	case tagOctStr, tagOpaque:
		if printable(b) {
			return &Value{S: string(b), IsStr: true}, nil
		}
		return &Value{S: fmt.Sprintf("%X", b), IsStr: true}, nil
	case tagOID:
		return &Value{S: decOID(b), IsStr: true}, nil
	case tagIPAddr:
		if len(b) == 4 {
			return &Value{S: fmt.Sprintf("%d.%d.%d.%d", b[0], b[1], b[2], b[3]), IsStr: true}, nil
		}
		return &Value{S: fmt.Sprintf("%X", b), IsStr: true}, nil
	case tagNull:
		return nil, fmt.Errorf("null value")
	case tagNoObject:
		return nil, fmt.Errorf("noSuchObject")
	case tagNoInst:
		return nil, fmt.Errorf("noSuchInstance")
	case tagEndOfMib:
		return nil, fmt.Errorf("endOfMibView")
	}
	return nil, fmt.Errorf("unsupported value tag 0x%02X", tag)
}

func printable(b []byte) bool {
	for _, c := range b {
		if c == '\n' || c == '\r' || c == '\t' {
			continue
		}
		if c < 0x20 || c > 0x7E && !unicode.IsPrint(rune(c)) {
			return false
		}
	}
	return true
}

func normOID(o string) string {
	o = strings.TrimSpace(o)
	o = strings.TrimPrefix(o, ".")
	// Zabbix 6.4+ may wrap: get[1.3.6...]
	if strings.HasPrefix(o, "get[") && strings.HasSuffix(o, "]") {
		o = o[4 : len(o)-1]
	}
	return o
}
