package snmp

import "testing"

func TestDecOID(t *testing.T) {
	cases := []struct {
		in   []byte
		want string
	}{
		{[]byte{0x2B, 0x06, 0x01, 0x02, 0x01}, "1.3.6.1.2.1"},
		// 1.3.6.1.4.1.41112.1.6 — 41112 = 0x82 0xC1 0x18 in base128
		{[]byte{0x2B, 0x06, 0x01, 0x04, 0x01, 0x82, 0xC1, 0x18, 0x01, 0x06}, "1.3.6.1.4.1.41112.1.6"},
		{[]byte{0x2B}, "1.3"},
	}
	for _, c := range cases {
		if got := decOID(c.in); got != c.want {
			t.Errorf("decOID(% X) = %q, want %q", c.in, got, c.want)
		}
	}
}

func TestOIDRoundTrip(t *testing.T) {
	for _, o := range []string{"1.3.6.1.2.1.1.2.0", "1.3.6.1.4.1.41112.1.6", "1.3.6.1.2.1.31.1.1.1.6.1"} {
		enc, err := encodeOID(o)
		if err != nil {
			t.Fatal(err)
		}
		r := &reader{b: enc}
		_, content, err := r.readTLV()
		if err != nil {
			t.Fatal(err)
		}
		if got := decOID(content); got != o {
			t.Errorf("roundtrip %q -> %q", o, got)
		}
	}
}
