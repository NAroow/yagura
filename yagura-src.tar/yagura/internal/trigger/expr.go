// Package trigger parses and evaluates a practical subset of the
// Zabbix 6+ trigger expression syntax, e.g.:
//
//	avg(/web01/system.cpu.load[all,avg1],5m) > 2
//	last(/db01/vfs.fs.size[/,pused]) > 90 and nodata(/db01/agent.ping,3m)=0
//
// Supported functions: last, avg, min, max, sum, count, nodata, change.
// Supported operators: + - * /  > >= < <= = <>  and or not, parentheses.
// Numeric constant suffixes: K M G T (×1024ⁿ) and s m h d w (seconds).
package trigger

import (
	"fmt"
	"strconv"
	"strings"
	"unicode"
)

// DataSource feeds the evaluator with history.
type DataSource interface {
	// Last returns the most recent value (numeric or string).
	Last(host, key string) (float64, string, bool, error) // value, str, isStr, err
	// Prev returns the value before the most recent one.
	Prev(host, key string) (float64, bool, error)
	// Window returns numeric values with timestamp >= now-sec.
	Window(host, key string, sec int64) ([]float64, error)
}

type Val struct {
	Num   float64
	Str   string
	IsStr bool
}

func (v Val) truthy() bool {
	if v.IsStr {
		return v.Str != ""
	}
	return v.Num != 0
}

func b2v(b bool) Val {
	if b {
		return Val{Num: 1}
	}
	return Val{Num: 0}
}

// ---- AST ----

type node interface {
	eval(ds DataSource) (Val, error)
}

type numNode float64

func (n numNode) eval(DataSource) (Val, error) { return Val{Num: float64(n)}, nil }

type strNode string

func (n strNode) eval(DataSource) (Val, error) { return Val{Str: string(n), IsStr: true}, nil }

type binNode struct {
	op   string
	l, r node
}

func (n *binNode) eval(ds DataSource) (Val, error) {
	l, err := n.l.eval(ds)
	if err != nil {
		return Val{}, err
	}
	r, err := n.r.eval(ds)
	if err != nil {
		return Val{}, err
	}
	switch n.op {
	case "and":
		return b2v(l.truthy() && r.truthy()), nil
	case "or":
		return b2v(l.truthy() || r.truthy()), nil
	case "=":
		if l.IsStr || r.IsStr {
			return b2v(l.Str == r.Str && l.IsStr == r.IsStr), nil
		}
		return b2v(l.Num == r.Num), nil
	case "<>":
		if l.IsStr || r.IsStr {
			return b2v(!(l.Str == r.Str && l.IsStr == r.IsStr)), nil
		}
		return b2v(l.Num != r.Num), nil
	}
	if l.IsStr || r.IsStr {
		return Val{}, fmt.Errorf("operator %q needs numeric operands", n.op)
	}
	switch n.op {
	case ">":
		return b2v(l.Num > r.Num), nil
	case ">=":
		return b2v(l.Num >= r.Num), nil
	case "<":
		return b2v(l.Num < r.Num), nil
	case "<=":
		return b2v(l.Num <= r.Num), nil
	case "+":
		return Val{Num: l.Num + r.Num}, nil
	case "-":
		return Val{Num: l.Num - r.Num}, nil
	case "*":
		return Val{Num: l.Num * r.Num}, nil
	case "/":
		if r.Num == 0 {
			return Val{}, fmt.Errorf("division by zero")
		}
		return Val{Num: l.Num / r.Num}, nil
	}
	return Val{}, fmt.Errorf("unknown operator %q", n.op)
}

type notNode struct{ x node }

func (n *notNode) eval(ds DataSource) (Val, error) {
	v, err := n.x.eval(ds)
	if err != nil {
		return Val{}, err
	}
	return b2v(!v.truthy()), nil
}

type negNode struct{ x node }

func (n *negNode) eval(ds DataSource) (Val, error) {
	v, err := n.x.eval(ds)
	if err != nil {
		return Val{}, err
	}
	if v.IsStr {
		return Val{}, fmt.Errorf("cannot negate a string")
	}
	return Val{Num: -v.Num}, nil
}

type funcNode struct {
	fn        string
	host, key string
	sec       int64 // window seconds (0 if absent)
}

func (n *funcNode) eval(ds DataSource) (Val, error) {
	switch n.fn {
	case "last":
		num, str, isStr, err := ds.Last(n.host, n.key)
		if err != nil {
			return Val{}, err
		}
		return Val{Num: num, Str: str, IsStr: isStr}, nil
	case "change":
		num, _, isStr, err := ds.Last(n.host, n.key)
		if err != nil {
			return Val{}, err
		}
		if isStr {
			return Val{}, fmt.Errorf("change() on text item")
		}
		prev, ok, err := ds.Prev(n.host, n.key)
		if err != nil {
			return Val{}, err
		}
		if !ok {
			return Val{}, fmt.Errorf("change(): not enough history")
		}
		return Val{Num: num - prev}, nil
	case "nodata":
		if n.sec <= 0 {
			return Val{}, fmt.Errorf("nodata() needs a time window")
		}
		vs, err := ds.Window(n.host, n.key, n.sec)
		if err != nil {
			return Val{}, err
		}
		return b2v(len(vs) == 0), nil
	case "avg", "min", "max", "sum", "count":
		if n.sec <= 0 {
			return Val{}, fmt.Errorf("%s() needs a time window", n.fn)
		}
		vs, err := ds.Window(n.host, n.key, n.sec)
		if err != nil {
			return Val{}, err
		}
		if n.fn == "count" {
			return Val{Num: float64(len(vs))}, nil
		}
		if len(vs) == 0 {
			return Val{}, fmt.Errorf("%s(): no data in window", n.fn)
		}
		acc := vs[0]
		for _, v := range vs[1:] {
			switch n.fn {
			case "avg", "sum":
				acc += v
			case "min":
				if v < acc {
					acc = v
				}
			case "max":
				if v > acc {
					acc = v
				}
			}
		}
		if n.fn == "avg" {
			acc /= float64(len(vs))
		}
		return Val{Num: acc}, nil
	}
	return Val{}, fmt.Errorf("unsupported function %q", n.fn)
}

// ---- parser (recursive descent over the raw string; the first
// function argument /host/key is scanned bracket-aware because item
// keys may contain commas and slashes, e.g. vfs.fs.size[/,pused]) ----

type parser struct {
	s   string
	pos int
}

type Expr struct {
	root node
	src  string
}

func (e *Expr) Eval(ds DataSource) (bool, error) {
	v, err := e.root.eval(ds)
	if err != nil {
		return false, err
	}
	return v.truthy(), nil
}

func (e *Expr) String() string { return e.src }

// Refs lists the /host/key pairs referenced by the expression.
func (e *Expr) Refs() [][2]string {
	var out [][2]string
	var walk func(n node)
	walk = func(n node) {
		switch t := n.(type) {
		case *funcNode:
			out = append(out, [2]string{t.host, t.key})
		case *binNode:
			walk(t.l)
			walk(t.r)
		case *notNode:
			walk(t.x)
		case *negNode:
			walk(t.x)
		}
	}
	walk(e.root)
	return out
}

func Parse(src string) (*Expr, error) {
	p := &parser{s: src}
	n, err := p.parseOr()
	if err != nil {
		return nil, err
	}
	p.ws()
	if p.pos != len(p.s) {
		return nil, fmt.Errorf("unexpected %q at position %d", p.rest(10), p.pos)
	}
	return &Expr{root: n, src: src}, nil
}

func (p *parser) rest(n int) string {
	r := p.s[p.pos:]
	if len(r) > n {
		r = r[:n]
	}
	return r
}

func (p *parser) ws() {
	for p.pos < len(p.s) && (p.s[p.pos] == ' ' || p.s[p.pos] == '\t' || p.s[p.pos] == '\n' || p.s[p.pos] == '\r') {
		p.pos++
	}
}

func (p *parser) word(w string) bool {
	p.ws()
	if strings.HasPrefix(p.s[p.pos:], w) {
		end := p.pos + len(w)
		if end == len(p.s) || !isIdent(rune(p.s[end])) {
			p.pos = end
			return true
		}
	}
	return false
}

func (p *parser) sym(sy string) bool {
	p.ws()
	if strings.HasPrefix(p.s[p.pos:], sy) {
		p.pos += len(sy)
		return true
	}
	return false
}

func isIdent(r rune) bool {
	return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '.'
}

func (p *parser) parseOr() (node, error) {
	l, err := p.parseAnd()
	if err != nil {
		return nil, err
	}
	for p.word("or") {
		r, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		l = &binNode{op: "or", l: l, r: r}
	}
	return l, nil
}

func (p *parser) parseAnd() (node, error) {
	l, err := p.parseCmp()
	if err != nil {
		return nil, err
	}
	for p.word("and") {
		r, err := p.parseCmp()
		if err != nil {
			return nil, err
		}
		l = &binNode{op: "and", l: l, r: r}
	}
	return l, nil
}

func (p *parser) parseCmp() (node, error) {
	l, err := p.parseAdd()
	if err != nil {
		return nil, err
	}
	for _, op := range []string{">=", "<=", "<>", ">", "<", "="} {
		if p.sym(op) {
			r, err := p.parseAdd()
			if err != nil {
				return nil, err
			}
			return &binNode{op: op, l: l, r: r}, nil
		}
	}
	return l, nil
}

func (p *parser) parseAdd() (node, error) {
	l, err := p.parseMul()
	if err != nil {
		return nil, err
	}
	for {
		if p.sym("+") {
			r, err := p.parseMul()
			if err != nil {
				return nil, err
			}
			l = &binNode{op: "+", l: l, r: r}
		} else if p.sym("-") {
			r, err := p.parseMul()
			if err != nil {
				return nil, err
			}
			l = &binNode{op: "-", l: l, r: r}
		} else {
			return l, nil
		}
	}
}

func (p *parser) parseMul() (node, error) {
	l, err := p.parseUnary()
	if err != nil {
		return nil, err
	}
	for {
		if p.sym("*") {
			r, err := p.parseUnary()
			if err != nil {
				return nil, err
			}
			l = &binNode{op: "*", l: l, r: r}
		} else if p.sym("/") {
			r, err := p.parseUnary()
			if err != nil {
				return nil, err
			}
			l = &binNode{op: "/", l: l, r: r}
		} else {
			return l, nil
		}
	}
}

func (p *parser) parseUnary() (node, error) {
	if p.word("not") {
		x, err := p.parseUnary()
		if err != nil {
			return nil, err
		}
		return &notNode{x: x}, nil
	}
	p.ws()
	if p.sym("-") {
		x, err := p.parseUnary()
		if err != nil {
			return nil, err
		}
		return &negNode{x: x}, nil
	}
	return p.parsePrimary()
}

func (p *parser) parsePrimary() (node, error) {
	p.ws()
	if p.pos >= len(p.s) {
		return nil, fmt.Errorf("unexpected end of expression")
	}
	c := p.s[p.pos]
	if c == '(' {
		p.pos++
		n, err := p.parseOr()
		if err != nil {
			return nil, err
		}
		if !p.sym(")") {
			return nil, fmt.Errorf("missing ')' at position %d", p.pos)
		}
		return n, nil
	}
	if c == '"' {
		return p.parseString()
	}
	if c >= '0' && c <= '9' || c == '.' {
		return p.parseNumber()
	}
	if unicode.IsLetter(rune(c)) {
		return p.parseFunc()
	}
	return nil, fmt.Errorf("unexpected %q at position %d", p.rest(10), p.pos)
}

func (p *parser) parseString() (node, error) {
	p.pos++ // opening quote
	var sb strings.Builder
	for p.pos < len(p.s) {
		c := p.s[p.pos]
		if c == '\\' && p.pos+1 < len(p.s) {
			p.pos++
			sb.WriteByte(p.s[p.pos])
			p.pos++
			continue
		}
		if c == '"' {
			p.pos++
			return strNode(sb.String()), nil
		}
		sb.WriteByte(c)
		p.pos++
	}
	return nil, fmt.Errorf("unterminated string")
}

func (p *parser) parseNumber() (node, error) {
	start := p.pos
	for p.pos < len(p.s) {
		c := p.s[p.pos]
		if c >= '0' && c <= '9' || c == '.' || c == 'e' || c == 'E' ||
			((c == '+' || c == '-') && p.pos > start && (p.s[p.pos-1] == 'e' || p.s[p.pos-1] == 'E')) {
			p.pos++
			continue
		}
		break
	}
	numStr := p.s[start:p.pos]
	mult := 1.0
	if p.pos < len(p.s) {
		switch p.s[p.pos] {
		case 'K':
			mult = 1 << 10
		case 'M':
			mult = 1 << 20
		case 'G':
			mult = 1 << 30
		case 'T':
			mult = 1 << 40
		case 's':
			mult = 1
		case 'm':
			mult = 60
		case 'h':
			mult = 3600
		case 'd':
			mult = 86400
		case 'w':
			mult = 604800
		}
		if mult != 1.0 || p.s[p.pos] == 's' {
			p.pos++
		}
	}
	v, err := strconv.ParseFloat(numStr, 64)
	if err != nil {
		return nil, fmt.Errorf("bad number %q", numStr)
	}
	return numNode(v * mult), nil
}

func (p *parser) parseFunc() (node, error) {
	start := p.pos
	for p.pos < len(p.s) && isIdent(rune(p.s[p.pos])) {
		p.pos++
	}
	fn := p.s[start:p.pos]
	if !p.sym("(") {
		return nil, fmt.Errorf("expected '(' after %q", fn)
	}
	p.ws()
	if p.pos >= len(p.s) || p.s[p.pos] != '/' {
		return nil, fmt.Errorf("%s(): first argument must be /host/key", fn)
	}
	p.pos++ // leading '/'
	hs := p.pos
	for p.pos < len(p.s) && p.s[p.pos] != '/' {
		p.pos++
	}
	if p.pos >= len(p.s) {
		return nil, fmt.Errorf("%s(): malformed /host/key", fn)
	}
	host := p.s[hs:p.pos]
	p.pos++ // '/'
	ks := p.pos
	depth := 0
	for p.pos < len(p.s) {
		c := p.s[p.pos]
		if c == '[' {
			depth++
		} else if c == ']' {
			depth--
		} else if depth == 0 && (c == ',' || c == ')') {
			break
		}
		p.pos++
	}
	key := strings.TrimSpace(p.s[ks:p.pos])
	f := &funcNode{fn: fn, host: host, key: key}
	// optional second argument: time window like 5m / 300 / #N (#N treated as N samples → unsupported, mapped to seconds heuristically rejected)
	if p.sym(",") {
		p.ws()
		as := p.pos
		for p.pos < len(p.s) && p.s[p.pos] != ',' && p.s[p.pos] != ')' {
			p.pos++
		}
		arg := strings.TrimSpace(p.s[as:p.pos])
		sec, err := ParseDuration(arg)
		if err != nil {
			return nil, fmt.Errorf("%s(): bad time window %q", fn, arg)
		}
		f.sec = sec
		// swallow any further args we don't support (e.g. time shift)
		for p.sym(",") {
			for p.pos < len(p.s) && p.s[p.pos] != ',' && p.s[p.pos] != ')' {
				p.pos++
			}
		}
	}
	if !p.sym(")") {
		return nil, fmt.Errorf("%s(): missing ')'", fn)
	}
	return f, nil
}

// ParseDuration converts "5m", "30s", "1h", "90" → seconds.
func ParseDuration(s string) (int64, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, fmt.Errorf("empty duration")
	}
	mult := int64(1)
	switch s[len(s)-1] {
	case 's':
		s = s[:len(s)-1]
	case 'm':
		mult, s = 60, s[:len(s)-1]
	case 'h':
		mult, s = 3600, s[:len(s)-1]
	case 'd':
		mult, s = 86400, s[:len(s)-1]
	case 'w':
		mult, s = 604800, s[:len(s)-1]
	}
	n, err := strconv.ParseInt(s, 10, 64)
	if err != nil {
		return 0, err
	}
	return n * mult, nil
}
