package trigger

import (
	"testing"
	"time"

	"yagura/internal/store"
)

// TestAvailabilityDetectsSilentHost is the regression guard for the bug where
// a shut-down host stayed "green" with no alert: yagura had no server-side
// liveness check, so detection depended on a nodata trigger the stock
// templates don't provide. sweepAvail must now flag a silent host on its own.
func TestAvailabilityDetectsSilentHost(t *testing.T) {
	st, err := store.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	h := st.AddHost(&store.Host{Name: "box", Addr: "127.0.0.1:10050", Enabled: true})
	it := st.AddItem(&store.Item{HostID: h.ID, Name: "Agent ping", Key: "agent.ping",
		Type: store.Passive, ValueType: store.VFloat, DelaySec: 60, Enabled: true})

	eng := &Engine{St: st}
	now := time.Now().Unix()

	// 1) Never polled yet → must NOT flag (keeps startup / fresh imports quiet).
	eng.sweepAvail()
	if _, down := st.ActiveHostDownProblem(h.ID); down {
		t.Fatal("host flagged before any data was ever collected")
	}

	// 2) Recent sample → reachable, no problem.
	mustIngest(t, st, it, now-5)
	eng.sweepAvail()
	if _, down := st.ActiveHostDownProblem(h.ID); down {
		t.Fatal("healthy host wrongly flagged unreachable")
	}

	// 3) Last contact well past the threshold → problem opens (the fix).
	mustIngest(t, st, it, now-600)
	eng.sweepAvail()
	p, down := st.ActiveHostDownProblem(h.ID)
	if !down {
		t.Fatal("silent host was NOT flagged unreachable")
	}
	if p.Severity != hostDownSeverity {
		t.Fatalf("severity = %d, want %d", p.Severity, hostDownSeverity)
	}

	// 4) Fresh sample → problem resolves.
	mustIngest(t, st, it, now)
	eng.sweepAvail()
	if _, down := st.ActiveHostDownProblem(h.ID); down {
		t.Fatal("unreachable problem not resolved after host recovered")
	}
}

// A disabled host must never raise (or keep) an unreachable problem.
func TestAvailabilitySkipsDisabledHost(t *testing.T) {
	st, err := store.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	h := st.AddHost(&store.Host{Name: "box", Addr: "127.0.0.1:10050", Enabled: false})
	it := st.AddItem(&store.Item{HostID: h.ID, Key: "agent.ping",
		Type: store.Passive, ValueType: store.VFloat, DelaySec: 60, Enabled: true})
	mustIngest(t, st, it, time.Now().Unix()-9999)

	(&Engine{St: st}).sweepAvail()
	if _, down := st.ActiveHostDownProblem(h.ID); down {
		t.Fatal("disabled host flagged unreachable")
	}
}

func mustIngest(t *testing.T, st *store.Store, it *store.Item, ts int64) {
	t.Helper()
	if err := st.Ingest(it, ts, "1"); err != nil {
		t.Fatal(err)
	}
}
