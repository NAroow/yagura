package trigger

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"

	"yagura/internal/store"
)

var sevNames = []string{"Not classified", "Information", "Warning", "Average", "High", "Disaster"}

func SeverityName(s int) string {
	if s >= 0 && s < len(sevNames) {
		return sevNames[s]
	}
	return "Unknown"
}

// Engine periodically evaluates every enabled trigger, maintains the
// problem lifecycle (open/close) and fires webhook notifications.
type Engine struct {
	St       *store.Store
	Interval time.Duration

	mu    sync.Mutex
	cache map[int64]*Expr // trigger id -> parsed expression
	errs  map[int64]string
}

func (e *Engine) Run(ctx context.Context) {
	if e.Interval == 0 {
		e.Interval = 15 * time.Second
	}
	e.cache = map[int64]*Expr{}
	e.errs = map[int64]string{}
	t := time.NewTicker(e.Interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			e.sweep()
		}
	}
}

// TriggerError reports the last evaluation error, if any.
func (e *Engine) TriggerError(id int64) string {
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.errs[id]
}

func (e *Engine) sweep() {
	for _, tr := range e.St.Triggers(0) {
		if !tr.Enabled {
			continue
		}
		fired, err := e.evalTrigger(tr)
		e.mu.Lock()
		if err != nil {
			e.errs[tr.ID] = err.Error()
		} else {
			delete(e.errs, tr.ID)
		}
		e.mu.Unlock()
		if err != nil {
			continue
		}
		prob, hasProb := e.St.ActiveProblem(tr.ID)
		host, _ := e.St.Host(tr.HostID)
		hostName := ""
		if host != nil {
			hostName = host.Name
		}
		if fired && !hasProb {
			p := e.St.OpenProblem(tr, hostName)
			log.Printf("PROBLEM [%s] %s: %s", SeverityName(p.Severity), hostName, tr.Name)
			e.notify(p, false)
		} else if !fired && hasProb {
			e.St.CloseProblem(prob.ID)
			log.Printf("RESOLVED %s: %s", hostName, tr.Name)
			e.notify(prob, true)
		}
	}
	e.sweepAvail()
}

// Host-unreachable problems are raised by the server itself, so monitoring a
// host actually detects it going down even when its templates carry no nodata
// trigger (e.g. the stock Zabbix Linux template keys availability off the
// internal item zabbix[host,agent,available], which yagura doesn't serve, and
// most SNMP templates have no liveness item at all).
const (
	hostDownName     = "Unreachable — no data from agent/SNMP"
	hostDownSeverity = 4 // High
)

// sweepAvail flags hosts that have stopped reporting. A host is unreachable
// when none of its server-polled items (passive/SNMP/active) has produced a
// sample within the threshold. The threshold is Settings.UnreachableSec, or —
// when that is 0 — three times the fastest item's interval (min 120s), which
// tolerates a couple of missed polls without false alarms.
func (e *Engine) sweepAvail() {
	cfg := e.St.Settings()
	now := time.Now().Unix()
	for _, h := range e.St.Hosts() {
		prob, hasProb := e.St.ActiveHostDownProblem(h.ID)
		lastSeen, minDelay, has := e.St.Availability(h.ID)

		// A host we can't actively poll, that's disabled, or that we've never
		// once heard from (fresh import / down since startup) is not judged —
		// clear any stale problem and move on. This keeps startup quiet.
		if !h.Enabled || !has || lastSeen == 0 {
			if hasProb {
				e.St.CloseProblem(prob.ID)
				log.Printf("RESOLVED %s: %s", h.Name, hostDownName)
				e.notify(prob, true)
			}
			continue
		}

		thr := int64(cfg.UnreachableSec)
		if thr <= 0 {
			thr = int64(minDelay) * 3
			if thr < 120 {
				thr = 120
			}
		}
		down := now-lastSeen > thr

		if down && !hasProb {
			p := e.St.OpenHostDownProblem(h, hostDownName, hostDownSeverity)
			log.Printf("PROBLEM [%s] %s: %s (silent %ds)", SeverityName(p.Severity), h.Name, hostDownName, now-lastSeen)
			e.notify(p, false)
		} else if !down && hasProb {
			e.St.CloseProblem(prob.ID)
			log.Printf("RESOLVED %s: %s", h.Name, hostDownName)
			e.notify(prob, true)
		}
	}
}

func (e *Engine) evalTrigger(tr *store.Trigger) (bool, error) {
	e.mu.Lock()
	ex, ok := e.cache[tr.ID]
	if !ok || ex.String() != tr.Expression {
		var err error
		ex, err = Parse(tr.Expression)
		if err != nil {
			e.mu.Unlock()
			return false, err
		}
		e.cache[tr.ID] = ex
	}
	e.mu.Unlock()
	return ex.Eval(&storeSource{st: e.St})
}

// storeSource adapts the store to the expression DataSource.
type storeSource struct{ st *store.Store }

func (s *storeSource) item(host, key string) (*store.Item, error) {
	h, ok := s.st.HostByName(host)
	if !ok {
		return nil, fmt.Errorf("host %q not found", host)
	}
	it, ok := s.st.ItemByKey(h.ID, key)
	if !ok {
		return nil, fmt.Errorf("item %q not found on %q", key, host)
	}
	return it, nil
}

func (s *storeSource) Last(host, key string) (float64, string, bool, error) {
	it, err := s.item(host, key)
	if err != nil {
		return 0, "", false, err
	}
	p, ok := s.st.TS.Last(it.ID)
	if !ok {
		return 0, "", false, fmt.Errorf("no data for %s/%s", host, key)
	}
	if it.ValueType == store.VFloat {
		return p.V, "", false, nil
	}
	return 0, p.S, true, nil
}

func (s *storeSource) Prev(host, key string) (float64, bool, error) {
	it, err := s.item(host, key)
	if err != nil {
		return 0, false, err
	}
	pts := s.st.TS.Recent(it.ID, 0)
	if len(pts) < 2 {
		return 0, false, nil
	}
	return pts[len(pts)-2].V, true, nil
}

func (s *storeSource) Window(host, key string, sec int64) ([]float64, error) {
	it, err := s.item(host, key)
	if err != nil {
		return nil, err
	}
	from := time.Now().Unix() - sec
	pts := s.st.TS.Recent(it.ID, from)
	out := make([]float64, 0, len(pts))
	for _, p := range pts {
		out = append(out, p.V)
	}
	return out, nil
}

// ---- notifications ----

var sevColors = []int{0x97AAB3, 0x7499FF, 0xFFC859, 0xFFA059, 0xE97659, 0xE45959}

func (e *Engine) notify(p *store.Problem, resolved bool) {
	cfg := e.St.Settings()
	if cfg.WebhookURL == "" {
		return
	}
	var body []byte
	if cfg.WebhookType == "discord" {
		title := "🔴 PROBLEM: " + p.Name
		color := sevColors[0]
		if p.Severity >= 0 && p.Severity < len(sevColors) {
			color = sevColors[p.Severity]
		}
		if resolved {
			title = "✅ RESOLVED: " + p.Name
			color = 0x59DB8F
		}
		body, _ = json.Marshal(map[string]any{
			"embeds": []map[string]any{{
				"title": title,
				"color": color,
				"fields": []map[string]any{
					{"name": "Host", "value": p.Host, "inline": true},
					{"name": "Severity", "value": SeverityName(p.Severity), "inline": true},
				},
				"timestamp": time.Now().UTC().Format(time.RFC3339),
			}},
		})
	} else {
		ev := "problem"
		if resolved {
			ev = "resolved"
		}
		body, _ = json.Marshal(map[string]any{
			"event": ev, "host": p.Host, "trigger": p.Name,
			"severity": p.Severity, "severity_name": SeverityName(p.Severity),
			"start": p.Start, "end": p.End,
		})
	}
	go func() {
		cli := &http.Client{Timeout: 10 * time.Second}
		resp, err := cli.Post(cfg.WebhookURL, "application/json", bytes.NewReader(body))
		if err != nil {
			log.Printf("webhook: %v", err)
			return
		}
		resp.Body.Close()
	}()
}

// TestNotify sends a sample alert to verify webhook settings.
func (e *Engine) TestNotify() {
	p := &store.Problem{Host: "yagura", Name: "Test notification — 通知テスト",
		Severity: 1, Start: time.Now().Unix()}
	e.notify(p, false)
}
