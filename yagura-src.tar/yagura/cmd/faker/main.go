// Test harness: runs a fake zabbix agent on :10050 answering keys,
// and can act as zabbix_sender. Used only for smoke testing.
package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net"
	"os"
	"time"

	snmpfake "yagura/internal/snmp"
	"yagura/internal/zbx"
)

func main() {
	switch os.Args[1] {
	case "agent":
		agent()
	case "send":
		send(os.Args[2], os.Args[3], os.Args[4]) // host key value
	case "getactive":
		getActive(os.Args[2])
	case "snmpagent":
		snmpAgent()
	}
}

func agent() {
	ln, err := net.Listen("tcp", "127.0.0.1:10050")
	if err != nil {
		panic(err)
	}
	fmt.Println("fake agent on :10050")
	for {
		c, err := ln.Accept()
		if err != nil {
			return
		}
		go func(c net.Conn) {
			defer c.Close()
			data, err := zbx.ReadPacket(c)
			if err != nil {
				return
			}
			key := string(data)
			var resp string
			switch key {
			case "agent.ping":
				resp = "1"
			case "system.cpu.load[all,avg1]":
				resp = fmt.Sprintf("%.2f", 0.5+rand.Float64()*3)
			case "vfs.fs.size[/,pused]":
				resp = fmt.Sprintf("%.1f", 91.0+rand.Float64()*3) // always >90 to fire trigger
			case "system.uname":
				resp = "Linux fakebox 6.6.0 x86_64"
			default:
				resp = "ZBX_NOTSUPPORTED\x00Unsupported item key."
			}
			zbx.WritePacket(c, []byte(resp))
		}(c)
	}
}

func send(host, key, value string) {
	addr := os.Getenv("YAGURA_TRAPPER")
	if addr == "" {
		addr = "127.0.0.1:10051"
	}
	c, err := net.DialTimeout("tcp", addr, 3*time.Second)
	if err != nil {
		panic(err)
	}
	defer c.Close()
	req := map[string]any{"request": "sender data", "data": []map[string]any{
		{"host": host, "key": key, "value": value},
	}}
	b, _ := json.Marshal(req)
	zbx.WritePacket(c, b)
	resp, err := zbx.ReadPacket(c)
	if err != nil {
		panic(err)
	}
	fmt.Println(string(resp))
}

func getActive(host string) {
	c, _ := net.DialTimeout("tcp", "127.0.0.1:10051", 3*time.Second)
	defer c.Close()
	b, _ := json.Marshal(map[string]string{"request": "active checks", "host": host})
	zbx.WritePacket(c, b)
	resp, _ := zbx.ReadPacket(c)
	fmt.Println(string(resp))
}

// snmpAgent runs a fake SNMP v2c agent on UDP :1161 (no root needed).
// Serves: sysDescr, sysUpTime, ifHCInOctets.1 (counts ~1MB/s).
func snmpAgent() {
	pc, err := net.ListenPacket("udp", "127.0.0.1:1161")
	if err != nil {
		panic(err)
	}
	fmt.Println("fake snmp agent on udp :1161")
	start := time.Now()
	buf := make([]byte, 65535)
	for {
		n, addr, err := pc.ReadFrom(buf)
		if err != nil {
			return
		}
		resp := snmpHandle(buf[:n], start)
		if resp != nil {
			pc.WriteTo(resp, addr)
		}
	}
}

func snmpHandle(req []byte, start time.Time) []byte {
	reqID, oids, ok := snmpfake.ParseGet(req)
	if !ok {
		return nil
	}
	vals := map[string]snmpfake.VB{}
	for _, o := range oids {
		switch o {
		case "1.3.6.1.2.1.1.1.0": // sysDescr
			vals[o] = snmpfake.VB{Str: "FakeOS fakebox v1.0", IsStr: true}
		case "1.3.6.1.2.1.1.3.0": // sysUpTime (TimeTicks, 1/100s)
			vals[o] = snmpfake.VB{Num: uint64(time.Since(start) / (10 * time.Millisecond)), Tag: 0x43}
		case "1.3.6.1.2.1.31.1.1.1.6.1": // ifHCInOctets.1 — Counter64 growing ~1MB/s
			vals[o] = snmpfake.VB{Num: uint64(time.Since(start).Seconds() * 1e6), Tag: 0x46}
		default:
			vals[o] = snmpfake.VB{NoSuch: true}
		}
	}
	return snmpfake.BuildResponse(reqID, oids, vals)
}
